"use strict";
(function(FUNCTION_TABLE_OFFSET) {
  var Module = {};
  var args = [];
  Module.arguments = [];
  var __globalConstructor__ = function globalConstructor() {};
  Runtime.QUANTUM_SIZE = 4;
  var $0___SIZE = 1776;
  var $1___SIZE = 16;
  var $2___SIZE = 196;
  var $struct_FILE___SIZE = 148;
  var $struct_FILE___FLATTENER = [ 0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60, 64, 68, 70, 71, 72, 76, 84, 88, 92, 96, 100, 104, 108 ];
  var $struct_PyBufferProcs___SIZE = 24;
  var $struct_PyGetSetDef___SIZE = 20;
  var $struct_PyIntObject___SIZE = 12;
  var $struct_PyMappingMethods___SIZE = 12;
  var $struct_PyMemberDef___SIZE = 0;
  var $struct_PyMemberDef___FLATTENER = [];
  var $struct_PyMethodDef___SIZE = 16;
  var $struct_PyNumberMethods___SIZE = 156;
  var $struct_PyObject___SIZE = 8;
  var $struct_PySequenceMethods___SIZE = 40;
  var $struct_PyStringObject___SIZE = 24;
  var $struct_PyTupleObject___SIZE = 16;
  var $struct_Py_buffer___SIZE = 52;
  var $struct_Py_buffer___FLATTENER = [ 0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 48 ];
  var $struct__IO_marker___SIZE = 12;
  var $struct__typeobject___SIZE = 196;
  var $struct_attrgetterobject___SIZE = 16;
  var $struct_methodcallerobject___SIZE = 20;
  var _operator_doc;
  var __str;
  var __str1;
  var __str2;
  var __str3;
  var __str4;
  var __str5;
  var __str6;
  var __str7;
  var __str8;
  var __str9;
  var __str10;
  var __str11;
  var __str12;
  var __str13;
  var __str14;
  var __str15;
  var __str16;
  var __str17;
  var __str18;
  var __str19;
  var __str20;
  var __str21;
  var __str22;
  var __str23;
  var __str24;
  var __str25;
  var __str26;
  var __str27;
  var __str28;
  var __str29;
  var __str30;
  var __str31;
  var __str32;
  var __str33;
  var __str34;
  var __str35;
  var __str36;
  var __str37;
  var __str38;
  var __str39;
  var __str40;
  var __str41;
  var __str42;
  var __str43;
  var __str44;
  var __str45;
  var __str46;
  var __str47;
  var __str48;
  var __str49;
  var __str50;
  var __str51;
  var __str52;
  var __str53;
  var __str54;
  var __str55;
  var __str56;
  var __str57;
  var __str58;
  var __str59;
  var __str60;
  var __str61;
  var __str62;
  var __str63;
  var __str64;
  var __str65;
  var __str66;
  var __str67;
  var __str68;
  var __str69;
  var __str70;
  var __str71;
  var __str72;
  var __str73;
  var __str74;
  var __str75;
  var __str76;
  var __str77;
  var __str78;
  var __str79;
  var __str80;
  var __str81;
  var __str82;
  var __str83;
  var __str84;
  var __str85;
  var __str86;
  var __str87;
  var __str88;
  var __str89;
  var __str90;
  var __str91;
  var __str92;
  var __str93;
  var __str94;
  var __str95;
  var __str96;
  var __str97;
  var __str98;
  var __str99;
  var __str100;
  var __str101;
  var __str102;
  var __str103;
  var __str104;
  var __str105;
  var __str106;
  var __str107;
  var __str108;
  var __str109;
  var __str110;
  var __str111;
  var __str112;
  var __str113;
  var __str114;
  var __str115;
  var __str116;
  var __str117;
  var __str118;
  var __str119;
  var __str120;
  var __str121;
  var __str122;
  var __str123;
  var __str124;
  var __str125;
  var __str126;
  var __str127;
  var __str128;
  var __str129;
  var __str130;
  var __str131;
  var __str132;
  var __str133;
  var __str134;
  var __str135;
  var __str136;
  var __str137;
  var __str138;
  var __str139;
  var __str140;
  var __str141;
  var __str142;
  var __str143;
  var __str144;
  var __str145;
  var __str146;
  var __str147;
  var __str148;
  var __str149;
  var __str150;
  var __str151;
  var __str152;
  var __str153;
  var __str154;
  var __str155;
  var __str156;
  var __str157;
  var __str158;
  var __str159;
  var __str160;
  var __str161;
  var __str162;
  var __str163;
  var __str164;
  var __str165;
  var __str166;
  var __str167;
  var __str168;
  var __str169;
  var __str170;
  var __str171;
  var __str172;
  var __str173;
  var __str174;
  var __str175;
  var __str176;
  var __str177;
  var __str178;
  var __str179;
  var __str180;
  var __str181;
  var __str182;
  var __str183;
  var __str184;
  var __str185;
  var __str186;
  var __str187;
  var __str188;
  var __str189;
  var __str190;
  var __str191;
  var __str192;
  var __str193;
  var __str194;
  var __str195;
  var __str196;
  var __str197;
  var __str198;
  var __str199;
  var __str200;
  var __str201;
  var __str202;
  var __str203;
  var __str204;
  var __str205;
  var __str206;
  var __str207;
  var __str208;
  var __str209;
  var __str210;
  var __str211;
  var __str212;
  var _operator_methods;
  var __str213;
  var __str214;
  var __str215;
  var __str216;
  var ___PRETTY_FUNCTION___9242;
  var __str217;
  var _itemgetter_doc;
  var __str218;
  var _itemgetter_type;
  var __str219;
  var __str220;
  var __str221;
  var __str222;
  var ___PRETTY_FUNCTION___9429;
  var __str223;
  var _attrgetter_doc;
  var __str224;
  var _attrgetter_type;
  var __str225;
  var __str226;
  var _methodcaller_doc;
  var __str227;
  var _methodcaller_type;
  var __str228;
  function _op_isCallable($x) {
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $x_addr;
      var $retval;
      var $0;
      $x_addr = $x;
      
      
      if (HEAP[_Py_Py3kWarningFlag] != 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 3;
        break;
      }
     case 1:
      var $3 = HEAP[_PyExc_DeprecationWarning];
      var $4 = _PyErr_WarnEx($3, __str, 1);
      
      if ($4 < 0) {
        __label__ = 2;
        break;
      } else {
        __label__ = 3;
        break;
      }
     case 2:
      $0 = -1;
      __label__ = 4;
      break;
     case 3:
      
      var $7 = _PyCallable_Check($x_addr);
      $0 = $7;
      __label__ = 4;
      break;
     case 4:
      
      $retval = $0;
      var $retval4 = $retval;
      return $retval4;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_sequenceIncludes($seq, $ob) {
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $seq_addr;
      var $ob_addr;
      var $retval;
      var $0;
      $seq_addr = $seq;
      $ob_addr = $ob;
      
      
      if (HEAP[_Py_Py3kWarningFlag] != 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 3;
        break;
      }
     case 1:
      var $3 = HEAP[_PyExc_DeprecationWarning];
      var $4 = _PyErr_WarnEx($3, __str1, 1);
      
      if ($4 < 0) {
        __label__ = 2;
        break;
      } else {
        __label__ = 3;
        break;
      }
     case 2:
      $0 = -1;
      __label__ = 4;
      break;
     case 3:
      
      
      var $8 = _PySequence_Contains($seq_addr, $ob_addr);
      $0 = $8;
      __label__ = 4;
      break;
     case 4:
      
      $retval = $0;
      var $retval4 = $retval;
      return $retval4;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _isCallable($s, $a1) {
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a1_addr;
      var $retval;
      var $0;
      var $r;
      $s_addr = $s;
      $a1_addr = $a1;
      
      var $2 = _op_isCallable($a1_addr);
      $r = $2;
      
      var $4 = $r == -1;
      if ($4) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      
      var $6 = _PyBool_FromLong($r);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _isNumberType($s, $a1) {
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a1_addr;
      var $retval;
      var $0;
      var $r;
      $s_addr = $s;
      $a1_addr = $a1;
      
      var $2 = _PyNumber_Check($a1_addr);
      $r = $2;
      
      var $4 = $r == -1;
      if ($4) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      
      var $6 = _PyBool_FromLong($r);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _truth($s, $a1) {
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a1_addr;
      var $retval;
      var $0;
      var $r;
      $s_addr = $s;
      $a1_addr = $a1;
      
      var $2 = _PyObject_IsTrue($a1_addr);
      $r = $2;
      
      var $4 = $r == -1;
      if ($4) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      
      var $6 = _PyBool_FromLong($r);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_add($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str2, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_Add($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_sub($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str3, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_Subtract($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_mul($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str4, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_Multiply($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_div($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str5, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_Divide($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_floordiv($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str6, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_FloorDivide($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_truediv($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str7, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_TrueDivide($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_mod($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str8, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_Remainder($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_neg($s, $a1) {
    
    var $s_addr;
    var $a1_addr;
    var $retval;
    var $0;
    $s_addr = $s;
    $a1_addr = $a1;
    
    var $2 = _PyNumber_Negative($a1_addr);
    $0 = $2;
    
    $retval = $0;
    var $retval1 = $retval;
    return $retval1;
  }
  function _op_pos($s, $a1) {
    
    var $s_addr;
    var $a1_addr;
    var $retval;
    var $0;
    $s_addr = $s;
    $a1_addr = $a1;
    
    var $2 = _PyNumber_Positive($a1_addr);
    $0 = $2;
    
    $retval = $0;
    var $retval1 = $retval;
    return $retval1;
  }
  function _op_abs($s, $a1) {
    
    var $s_addr;
    var $a1_addr;
    var $retval;
    var $0;
    $s_addr = $s;
    $a1_addr = $a1;
    
    var $2 = _PyNumber_Absolute($a1_addr);
    $0 = $2;
    
    $retval = $0;
    var $retval1 = $retval;
    return $retval1;
  }
  function _op_inv($s, $a1) {
    
    var $s_addr;
    var $a1_addr;
    var $retval;
    var $0;
    $s_addr = $s;
    $a1_addr = $a1;
    
    var $2 = _PyNumber_Invert($a1_addr);
    $0 = $2;
    
    $retval = $0;
    var $retval1 = $retval;
    return $retval1;
  }
  function _op_invert($s, $a1) {
    
    var $s_addr;
    var $a1_addr;
    var $retval;
    var $0;
    $s_addr = $s;
    $a1_addr = $a1;
    
    var $2 = _PyNumber_Invert($a1_addr);
    $0 = $2;
    
    $retval = $0;
    var $retval1 = $retval;
    return $retval1;
  }
  function _op_lshift($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str9, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_Lshift($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_rshift($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str10, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_Rshift($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_not_($s, $a1) {
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a1_addr;
      var $retval;
      var $0;
      var $r;
      $s_addr = $s;
      $a1_addr = $a1;
      
      var $2 = _PyObject_Not($a1_addr);
      $r = $2;
      
      var $4 = $r == -1;
      if ($4) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      
      var $6 = _PyBool_FromLong($r);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_and_($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str11, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_And($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_xor($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str12, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_Xor($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_or_($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str13, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_Or($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_iadd($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str14, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_InPlaceAdd($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_isub($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str15, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_InPlaceSubtract($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_imul($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str16, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_InPlaceMultiply($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_idiv($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str17, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_InPlaceDivide($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_ifloordiv($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str18, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_InPlaceFloorDivide($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_itruediv($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str19, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_InPlaceTrueDivide($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_imod($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str20, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_InPlaceRemainder($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_ilshift($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str21, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_InPlaceLshift($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_irshift($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str22, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_InPlaceRshift($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_iand($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str23, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_InPlaceAnd($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_ixor($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str24, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_InPlaceXor($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_ior($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str25, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_InPlaceOr($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _isSequenceType($s, $a1) {
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a1_addr;
      var $retval;
      var $0;
      var $r;
      $s_addr = $s;
      $a1_addr = $a1;
      
      var $2 = _PySequence_Check($a1_addr);
      $r = $2;
      
      var $4 = $r == -1;
      if ($4) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      
      var $6 = _PyBool_FromLong($r);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_concat($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str26, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PySequence_Concat($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_repeat($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_ParseTuple($a_addr, __str27, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "i32*", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PySequence_Repeat($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_iconcat($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str28, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PySequence_InPlaceConcat($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_irepeat($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_ParseTuple($a_addr, __str29, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "i32*", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PySequence_InPlaceRepeat($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_contains($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      var $r;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str30, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 5;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PySequence_Contains($5, $4);
      $r = $6;
      
      var $8 = $r == -1;
      if ($8) {
        __label__ = 3;
        break;
      } else {
        __label__ = 4;
        break;
      }
     case 3:
      $0 = 0;
      __label__ = 5;
      break;
     case 4:
      
      var $10 = _PyBool_FromLong($r);
      $0 = $10;
      __label__ = 5;
      break;
     case 5:
      
      $retval = $0;
      var $retval5 = $retval;
      STACKTOP = __stackBase__;
      return $retval5;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _sequenceIncludes($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      var $r;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str31, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 5;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _op_sequenceIncludes($5, $4);
      $r = $6;
      
      var $8 = $r == -1;
      if ($8) {
        __label__ = 3;
        break;
      } else {
        __label__ = 4;
        break;
      }
     case 3:
      $0 = 0;
      __label__ = 5;
      break;
     case 4:
      
      var $10 = _PyBool_FromLong($r);
      $0 = $10;
      __label__ = 5;
      break;
     case 5:
      
      $retval = $0;
      var $retval5 = $retval;
      STACKTOP = __stackBase__;
      return $retval5;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _indexOf($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      var $r;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str32, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 5;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PySequence_Index($5, $4);
      $r = $6;
      
      var $8 = $r == -1;
      if ($8) {
        __label__ = 3;
        break;
      } else {
        __label__ = 4;
        break;
      }
     case 3:
      $0 = 0;
      __label__ = 5;
      break;
     case 4:
      
      var $10 = _PyInt_FromSsize_t($r);
      $0 = $10;
      __label__ = 5;
      break;
     case 5:
      
      $retval = $0;
      var $retval5 = $retval;
      STACKTOP = __stackBase__;
      return $retval5;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _countOf($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      var $r;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str33, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 5;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PySequence_Count($5, $4);
      $r = $6;
      
      var $8 = $r == -1;
      if ($8) {
        __label__ = 3;
        break;
      } else {
        __label__ = 4;
        break;
      }
     case 3:
      $0 = 0;
      __label__ = 5;
      break;
     case 4:
      
      var $10 = _PyInt_FromSsize_t($r);
      $0 = $10;
      __label__ = 5;
      break;
     case 5:
      
      $retval = $0;
      var $retval5 = $retval;
      STACKTOP = __stackBase__;
      return $retval5;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _isMappingType($s, $a1) {
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a1_addr;
      var $retval;
      var $0;
      var $r;
      $s_addr = $s;
      $a1_addr = $a1;
      
      var $2 = _PyMapping_Check($a1_addr);
      $r = $2;
      
      var $4 = $r == -1;
      if ($4) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      
      var $6 = _PyBool_FromLong($r);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_getitem($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str34, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyObject_GetItem($5, $4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_delitem($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str35, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 5;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyObject_DelItem($5, $4);
      var $7 = $6 == -1;
      if ($7) {
        __label__ = 3;
        break;
      } else {
        __label__ = 4;
        break;
      }
     case 3:
      $0 = 0;
      __label__ = 5;
      break;
     case 4:
      
      var $9 = HEAP[__Py_NoneStruct] + 1;
      HEAP[__Py_NoneStruct] = $9;
      $0 = __Py_NoneStruct;
      __label__ = 5;
      break;
     case 5:
      
      $retval = $0;
      var $retval5 = $retval;
      STACKTOP = __stackBase__;
      return $retval5;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_setitem($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 12;
    _memset(__stackBase__, 0, 12);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      var $a3 = __stackBase__ + 8;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str36, 3, 3, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0, $a3, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 5;
      break;
     case 2:
      var $4 = HEAP[$a3];
      var $5 = HEAP[$a2];
      var $6 = HEAP[$a1];
      var $7 = _PyObject_SetItem($6, $5, $4);
      var $8 = $7 == -1;
      if ($8) {
        __label__ = 3;
        break;
      } else {
        __label__ = 4;
        break;
      }
     case 3:
      $0 = 0;
      __label__ = 5;
      break;
     case 4:
      
      var $10 = HEAP[__Py_NoneStruct] + 1;
      HEAP[__Py_NoneStruct] = $10;
      $0 = __Py_NoneStruct;
      __label__ = 5;
      break;
     case 5:
      
      $retval = $0;
      var $retval5 = $retval;
      STACKTOP = __stackBase__;
      return $retval5;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_lt($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str37, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyObject_RichCompare($5, $4, 0);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_le($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str38, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyObject_RichCompare($5, $4, 1);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_eq($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str39, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyObject_RichCompare($5, $4, 2);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_ne($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str40, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyObject_RichCompare($5, $4, 3);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_gt($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str41, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyObject_RichCompare($5, $4, 4);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_ge($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str42, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyObject_RichCompare($5, $4, 5);
      $0 = $6;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_pow($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str43, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 != 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_Power($5, $4, __Py_NoneStruct);
      $0 = $6;
      __label__ = 3;
      break;
     case 2:
      $0 = 0;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_ipow($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str44, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 != 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      var $4 = HEAP[$a2];
      var $5 = HEAP[$a1];
      var $6 = _PyNumber_InPlacePower($5, $4, __Py_NoneStruct);
      $0 = $6;
      __label__ = 3;
      break;
     case 2:
      $0 = 0;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_index($s, $a) {
    
    var $s_addr;
    var $a_addr;
    var $retval;
    var $0;
    $s_addr = $s;
    $a_addr = $a;
    
    var $2 = _PyNumber_Index($a_addr);
    $0 = $2;
    
    $retval = $0;
    var $retval1 = $retval;
    return $retval1;
  }
  function _is_($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $iftmp_91;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      var $result;
      $s_addr = $s;
      $a_addr = $a;
      $result = 0;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str45, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 != 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 5;
        break;
      }
     case 1:
      
      
      
      if (HEAP[$a1] == HEAP[$a2]) {
        __label__ = 2;
        break;
      } else {
        __label__ = 3;
        break;
      }
     case 2:
      $iftmp_91 = __Py_TrueStruct;
      __label__ = 4;
      break;
     case 3:
      $iftmp_91 = __Py_ZeroStruct;
      __label__ = 4;
      break;
     case 4:
      
      $result = $iftmp_91;
      
      
      
      var $11 = HEAP[$result] + 1;
      
      
      HEAP[$result] = $11;
      __label__ = 5;
      break;
     case 5:
      
      $0 = $result;
      
      $retval = $0;
      var $retval5 = $retval;
      STACKTOP = __stackBase__;
      return $retval5;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _is_not($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 8;
    _memset(__stackBase__, 0, 8);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $iftmp_94;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      var $result;
      $s_addr = $s;
      $a_addr = $a;
      $result = 0;
      
      var $2 = _PyArg_UnpackTuple($a_addr, __str46, 2, 2, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 != 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 5;
        break;
      }
     case 1:
      
      
      
      if (HEAP[$a1] != HEAP[$a2]) {
        __label__ = 2;
        break;
      } else {
        __label__ = 3;
        break;
      }
     case 2:
      $iftmp_94 = __Py_TrueStruct;
      __label__ = 4;
      break;
     case 3:
      $iftmp_94 = __Py_ZeroStruct;
      __label__ = 4;
      break;
     case 4:
      
      $result = $iftmp_94;
      
      
      
      var $11 = HEAP[$result] + 1;
      
      
      HEAP[$result] = $11;
      __label__ = 5;
      break;
     case 5:
      
      $0 = $result;
      
      $retval = $0;
      var $retval5 = $retval;
      STACKTOP = __stackBase__;
      return $retval5;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_getslice($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 12;
    _memset(__stackBase__, 0, 12);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      var $a3 = __stackBase__ + 8;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_ParseTuple($a_addr, __str47, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0, $a3, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "i32*", 0, 0, 0, "i32*", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 3;
      break;
     case 2:
      var $4 = HEAP[$a3];
      var $5 = HEAP[$a2];
      var $6 = HEAP[$a1];
      var $7 = _PySequence_GetSlice($6, $5, $4);
      $0 = $7;
      __label__ = 3;
      break;
     case 3:
      
      $retval = $0;
      var $retval3 = $retval;
      STACKTOP = __stackBase__;
      return $retval3;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_setslice($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 16;
    _memset(__stackBase__, 0, 16);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a4 = __stackBase__ + 4;
      var $a2 = __stackBase__ + 8;
      var $a3 = __stackBase__ + 12;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_ParseTuple($a_addr, __str48, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0, $a3, 0, 0, 0, $a4, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "i32*", 0, 0, 0, "i32*", 0, 0, 0, "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 5;
      break;
     case 2:
      var $4 = HEAP[$a4];
      var $5 = HEAP[$a3];
      var $6 = HEAP[$a2];
      var $7 = HEAP[$a1];
      var $8 = _PySequence_SetSlice($7, $6, $5, $4);
      var $9 = $8 == -1;
      if ($9) {
        __label__ = 3;
        break;
      } else {
        __label__ = 4;
        break;
      }
     case 3:
      $0 = 0;
      __label__ = 5;
      break;
     case 4:
      
      var $11 = HEAP[__Py_NoneStruct] + 1;
      HEAP[__Py_NoneStruct] = $11;
      $0 = __Py_NoneStruct;
      __label__ = 5;
      break;
     case 5:
      
      $retval = $0;
      var $retval5 = $retval;
      STACKTOP = __stackBase__;
      return $retval5;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _op_delslice($s, $a) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 12;
    _memset(__stackBase__, 0, 12);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $s_addr;
      var $a_addr;
      var $retval;
      var $0;
      var $a1 = __stackBase__;
      var $a2 = __stackBase__ + 4;
      var $a3 = __stackBase__ + 8;
      $s_addr = $s;
      $a_addr = $a;
      
      var $2 = _PyArg_ParseTuple($a_addr, __str49, allocate([ $a1, 0, 0, 0, $a2, 0, 0, 0, $a3, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0, "i32*", 0, 0, 0, "i32*", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 5;
      break;
     case 2:
      var $4 = HEAP[$a3];
      var $5 = HEAP[$a2];
      var $6 = HEAP[$a1];
      var $7 = _PySequence_DelSlice($6, $5, $4);
      var $8 = $7 == -1;
      if ($8) {
        __label__ = 3;
        break;
      } else {
        __label__ = 4;
        break;
      }
     case 3:
      $0 = 0;
      __label__ = 5;
      break;
     case 4:
      
      var $10 = HEAP[__Py_NoneStruct] + 1;
      HEAP[__Py_NoneStruct] = $10;
      $0 = __Py_NoneStruct;
      __label__ = 5;
      break;
     case 5:
      
      $retval = $0;
      var $retval5 = $retval;
      STACKTOP = __stackBase__;
      return $retval5;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _itemgetter_new($type, $args, $kwds) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 4;
    _memset(__stackBase__, 0, 4);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $type_addr;
      var $args_addr;
      var $kwds_addr;
      var $retval;
      var $0;
      var $ig;
      var $item = __stackBase__;
      var $nitems;
      $type_addr = $type;
      $args_addr = $args;
      $kwds_addr = $kwds;
      
      var $2 = __PyArg_NoKeywords(__str213, $kwds_addr);
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 9;
      break;
     case 2:
      
      
      
      
      $nitems = HEAP[$args_addr + 8];
      
      
      var $10 = $args_addr;
      if ($nitems <= 1) {
        __label__ = 3;
        break;
      } else {
        __label__ = 5;
        break;
      }
     case 3:
      var $11 = _PyArg_UnpackTuple($10, __str214, 1, 1, allocate([ $item, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($11 == 0) {
        __label__ = 4;
        break;
      } else {
        __label__ = 6;
        break;
      }
     case 4:
      $0 = 0;
      __label__ = 9;
      break;
     case 5:
      HEAP[$item] = $10;
      __label__ = 6;
      break;
     case 6:
      var $13 = __PyObject_GC_New(_itemgetter_type);
      
      $ig = $13;
      
      if ($13 == 0) {
        __label__ = 7;
        break;
      } else {
        __label__ = 8;
        break;
      }
     case 7:
      $0 = 0;
      __label__ = 9;
      break;
     case 8:
      
      
      
      var $19 = HEAP[HEAP[$item]] + 1;
      var $20 = HEAP[$item];
      HEAP[$20] = $19;
      var $21 = HEAP[$item];
      
      
      HEAP[$ig + 12] = $21;
      
      
      
      HEAP[$ig + 8] = $nitems;
      
      
      _PyObject_GC_Track($ig);
      
      
      $0 = $ig;
      __label__ = 9;
      break;
     case 9:
      
      $retval = $0;
      var $retval10 = $retval;
      STACKTOP = __stackBase__;
      return $retval10;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _itemgetter_dealloc($ig) {
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $ig_addr;
      $ig_addr = $ig;
      
      
      _PyObject_GC_UnTrack($ig_addr);
      
      
      
      
      if (HEAP[$ig_addr + 12] != 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 3;
        break;
      }
     case 1:
      
      
      var $8 = HEAP[$ig_addr + 12];
      
      
      var $11 = HEAP[$8] - 1;
      var $12 = $8;
      HEAP[$12] = $11;
      
      
      
      if (HEAP[$8] == 0) {
        __label__ = 2;
        break;
      } else {
        __label__ = 3;
        break;
      }
     case 2:
      
      
      
      
      
      
      var $22 = HEAP[HEAP[HEAP[$ig_addr + 12] + 4] + 24];
      
      
      var $25 = HEAP[$ig_addr + 12];
      FUNCTION_TABLE[$22]($25);
      __label__ = 3;
      break;
     case 3:
      
      
      _PyObject_GC_Del($ig_addr);
      return;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _itemgetter_traverse($ig, $visit, $arg) {
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $ig_addr;
      var $visit_addr;
      var $arg_addr;
      var $retval;
      var $0;
      var $vret;
      $ig_addr = $ig;
      $visit_addr = $visit;
      $arg_addr = $arg;
      
      
      
      
      if (HEAP[$ig_addr + 12] != 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 3;
        break;
      }
     case 1:
      
      
      var $7 = HEAP[$ig_addr + 12];
      var $8 = $visit_addr;
      
      var $10 = FUNCTION_TABLE[$8]($7, $arg_addr);
      $vret = $10;
      
      
      if ($vret != 0) {
        __label__ = 2;
        break;
      } else {
        __label__ = 3;
        break;
      }
     case 2:
      
      $0 = $vret;
      __label__ = 4;
      break;
     case 3:
      $0 = 0;
      __label__ = 4;
      break;
     case 4:
      
      $retval = $0;
      var $retval4 = $retval;
      return $retval4;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _itemgetter_call($ig, $args, $kw) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 4;
    _memset(__stackBase__, 0, 4);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $ig_addr;
      var $args_addr;
      var $kw_addr;
      var $retval;
      var $0;
      var $obj = __stackBase__;
      var $result;
      var $i;
      var $nitems;
      var $item;
      var $val;
      $ig_addr = $ig;
      $args_addr = $args;
      $kw_addr = $kw;
      
      
      
      $nitems = HEAP[$ig_addr + 8];
      
      var $5 = _PyArg_UnpackTuple($args_addr, __str214, 1, 1, allocate([ $obj, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($5 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 18;
      break;
     case 2:
      
      
      
      
      var $11 = HEAP[$ig_addr + 12];
      if ($nitems == 1) {
        __label__ = 3;
        break;
      } else {
        __label__ = 4;
        break;
      }
     case 3:
      var $12 = HEAP[$obj];
      var $13 = _PyObject_GetItem($12, $11);
      $0 = $13;
      __label__ = 18;
      break;
     case 4:
      
      
      
      
      
      
      if ((HEAP[HEAP[$11 + 4] + 84] & 67108864) == 0) {
        __label__ = 5;
        break;
      } else {
        __label__ = 6;
        break;
      }
     case 5:
      ___assert_fail(__str215, __str216, 391, ___PRETTY_FUNCTION___9242);
      throw "Reached an unreachable!";
     case 6:
      
      
      
      
      
      
      
      
      if (HEAP[HEAP[$ig_addr + 12] + 8] != $nitems) {
        __label__ = 7;
        break;
      } else {
        __label__ = 8;
        break;
      }
     case 7:
      ___assert_fail(__str217, __str216, 392, ___PRETTY_FUNCTION___9242);
      throw "Reached an unreachable!";
     case 8:
      
      var $29 = _PyTuple_New($nitems);
      $result = $29;
      
      
      if ($result == 0) {
        __label__ = 9;
        break;
      } else {
        __label__ = 10;
        break;
      }
     case 9:
      $0 = 0;
      __label__ = 18;
      break;
     case 10:
      $i = 0;
      __label__ = 16;
      break;
     case 11:
      
      
      
      
      
      
      
      
      $item = HEAP[HEAP[$ig_addr + 12] + 12 + $i * 4];
      var $40 = HEAP[$obj];
      
      var $42 = _PyObject_GetItem($40, $item);
      $val = $42;
      
      
      var $45 = $result;
      if ($val == 0) {
        __label__ = 12;
        break;
      } else {
        __label__ = 15;
        break;
      }
     case 12:
      
      
      var $48 = HEAP[$45] - 1;
      
      
      HEAP[$result] = $48;
      
      
      
      
      if (HEAP[$result] == 0) {
        __label__ = 13;
        break;
      } else {
        __label__ = 14;
        break;
      }
     case 13:
      
      
      
      
      var $59 = HEAP[HEAP[$result + 4] + 24];
      
      FUNCTION_TABLE[$59]($result);
      __label__ = 14;
      break;
     case 14:
      $0 = 0;
      __label__ = 18;
      break;
     case 15:
      
      
      
      
      
      HEAP[$45 + 12 + $i * 4] = $val;
      
      var $67 = $i + 1;
      $i = $67;
      __label__ = 16;
      break;
     case 16:
      
      
      
      if ($i < $nitems) {
        __label__ = 11;
        break;
      } else {
        __label__ = 17;
        break;
      }
     case 17:
      
      $0 = $result;
      __label__ = 18;
      break;
     case 18:
      
      $retval = $0;
      var $retval18 = $retval;
      STACKTOP = __stackBase__;
      return $retval18;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _attrgetter_new($type, $args, $kwds) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 4;
    _memset(__stackBase__, 0, 4);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $type_addr;
      var $args_addr;
      var $kwds_addr;
      var $retval;
      var $0;
      var $ag;
      var $attr = __stackBase__;
      var $nattrs;
      $type_addr = $type;
      $args_addr = $args;
      $kwds_addr = $kwds;
      
      var $2 = __PyArg_NoKeywords(__str219, $kwds_addr);
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 9;
      break;
     case 2:
      
      
      
      
      $nattrs = HEAP[$args_addr + 8];
      
      
      var $10 = $args_addr;
      if ($nattrs <= 1) {
        __label__ = 3;
        break;
      } else {
        __label__ = 5;
        break;
      }
     case 3:
      var $11 = _PyArg_UnpackTuple($10, __str220, 1, 1, allocate([ $attr, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($11 == 0) {
        __label__ = 4;
        break;
      } else {
        __label__ = 6;
        break;
      }
     case 4:
      $0 = 0;
      __label__ = 9;
      break;
     case 5:
      HEAP[$attr] = $10;
      __label__ = 6;
      break;
     case 6:
      var $13 = __PyObject_GC_New(_attrgetter_type);
      
      $ag = $13;
      
      if ($13 == 0) {
        __label__ = 7;
        break;
      } else {
        __label__ = 8;
        break;
      }
     case 7:
      $0 = 0;
      __label__ = 9;
      break;
     case 8:
      
      
      
      var $19 = HEAP[HEAP[$attr]] + 1;
      var $20 = HEAP[$attr];
      HEAP[$20] = $19;
      var $21 = HEAP[$attr];
      
      
      HEAP[$ag + 12] = $21;
      
      
      
      HEAP[$ag + 8] = $nattrs;
      
      
      _PyObject_GC_Track($ag);
      
      
      $0 = $ag;
      __label__ = 9;
      break;
     case 9:
      
      $retval = $0;
      var $retval10 = $retval;
      STACKTOP = __stackBase__;
      return $retval10;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _attrgetter_dealloc($ag) {
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $ag_addr;
      $ag_addr = $ag;
      
      
      _PyObject_GC_UnTrack($ag_addr);
      
      
      
      
      if (HEAP[$ag_addr + 12] != 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 3;
        break;
      }
     case 1:
      
      
      var $8 = HEAP[$ag_addr + 12];
      
      
      var $11 = HEAP[$8] - 1;
      var $12 = $8;
      HEAP[$12] = $11;
      
      
      
      if (HEAP[$8] == 0) {
        __label__ = 2;
        break;
      } else {
        __label__ = 3;
        break;
      }
     case 2:
      
      
      
      
      
      
      var $22 = HEAP[HEAP[HEAP[$ag_addr + 12] + 4] + 24];
      
      
      var $25 = HEAP[$ag_addr + 12];
      FUNCTION_TABLE[$22]($25);
      __label__ = 3;
      break;
     case 3:
      
      
      _PyObject_GC_Del($ag_addr);
      return;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _attrgetter_traverse($ag, $visit, $arg) {
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $ag_addr;
      var $visit_addr;
      var $arg_addr;
      var $retval;
      var $0;
      var $vret;
      $ag_addr = $ag;
      $visit_addr = $visit;
      $arg_addr = $arg;
      
      
      
      
      if (HEAP[$ag_addr + 12] != 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 3;
        break;
      }
     case 1:
      
      
      var $7 = HEAP[$ag_addr + 12];
      var $8 = $visit_addr;
      
      var $10 = FUNCTION_TABLE[$8]($7, $arg_addr);
      $vret = $10;
      
      
      if ($vret != 0) {
        __label__ = 2;
        break;
      } else {
        __label__ = 3;
        break;
      }
     case 2:
      
      $0 = $vret;
      __label__ = 4;
      break;
     case 3:
      $0 = 0;
      __label__ = 4;
      break;
     case 4:
      
      $retval = $0;
      var $retval4 = $retval;
      return $retval4;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _dotted_getattr($obj, $attr) {
    var __label__;
    var __lastLabel__ = null;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $obj_addr;
      var $attr_addr;
      var $retval;
      var $iftmp_120;
      var $0;
      var $s;
      var $p;
      var $newobj;
      var $str;
      $obj_addr = $obj;
      $attr_addr = $attr;
      
      
      
      
      
      
      
      if ((HEAP[HEAP[$attr_addr + 4] + 84] & 268435456) != 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 3;
        break;
      }
     case 1:
      
      var $9 = __PyUnicodeUCS2_AsDefaultEncodedString($attr_addr, 0);
      $attr_addr = $9;
      
      
      if ($attr_addr == 0) {
        __label__ = 2;
        break;
      } else {
        __label__ = 3;
        break;
      }
     case 2:
      $0 = 0;
      __label__ = 22;
      break;
     case 3:
      
      
      
      
      
      
      
      if ((HEAP[HEAP[$attr_addr + 4] + 84] & 134217728) == 0) {
        __label__ = 4;
        break;
      } else {
        __label__ = 5;
        break;
      }
     case 4:
      var $19 = HEAP[_PyExc_TypeError];
      _PyErr_SetString($19, __str221);
      $0 = 0;
      __label__ = 22;
      break;
     case 5:
      
      
      
      
      $s = $attr_addr + 20;
      
      
      
      var $27 = HEAP[$obj_addr] + 1;
      
      
      HEAP[$obj_addr] = $27;
      __label__ = 6;
      break;
     case 6:
      
      var $31 = _strchr($s, 46);
      $p = $31;
      
      if ($31 != 0) {
        __label__ = 7;
        break;
      } else {
        __label__ = 8;
        break;
      }
     case 7:
      
      
      
      
      
      
      var $39 = _PyString_FromStringAndSize($s, $p - $s);
      $iftmp_120 = $39;
      __lastLabel__ = 7;
      __label__ = 9;
      break;
     case 8:
      
      var $41 = _PyString_FromString($s);
      $iftmp_120 = $41;
      __lastLabel__ = 8;
      __label__ = 9;
      break;
     case 9:
      var $42 = __lastLabel__ == 8 ? $41 : $39;
      $str = $42;
      
      var $44 = $obj_addr;
      if ($42 == 0) {
        __label__ = 10;
        break;
      } else {
        __label__ = 13;
        break;
      }
     case 10:
      
      
      var $47 = HEAP[$44] - 1;
      
      
      HEAP[$obj_addr] = $47;
      
      
      
      
      if (HEAP[$obj_addr] == 0) {
        __label__ = 11;
        break;
      } else {
        __label__ = 12;
        break;
      }
     case 11:
      
      
      
      
      var $58 = HEAP[HEAP[$obj_addr + 4] + 24];
      
      FUNCTION_TABLE[$58]($obj_addr);
      __label__ = 12;
      break;
     case 12:
      $0 = 0;
      __label__ = 22;
      break;
     case 13:
      
      var $61 = _PyObject_GetAttr($44, $str);
      $newobj = $61;
      
      
      
      var $65 = HEAP[$str] - 1;
      
      
      HEAP[$str] = $65;
      
      
      
      
      if (HEAP[$str] == 0) {
        __label__ = 14;
        break;
      } else {
        __label__ = 15;
        break;
      }
     case 14:
      
      
      
      
      var $76 = HEAP[HEAP[$str + 4] + 24];
      
      FUNCTION_TABLE[$76]($str);
      __label__ = 15;
      break;
     case 15:
      
      
      
      var $81 = HEAP[$obj_addr] - 1;
      
      
      HEAP[$obj_addr] = $81;
      
      
      
      
      if (HEAP[$obj_addr] == 0) {
        __label__ = 16;
        break;
      } else {
        __label__ = 17;
        break;
      }
     case 16:
      
      
      
      
      var $92 = HEAP[HEAP[$obj_addr + 4] + 24];
      
      FUNCTION_TABLE[$92]($obj_addr);
      __label__ = 17;
      break;
     case 17:
      
      
      if ($newobj == 0) {
        __label__ = 18;
        break;
      } else {
        __label__ = 19;
        break;
      }
     case 18:
      $0 = 0;
      __label__ = 22;
      break;
     case 19:
      
      $obj_addr = $newobj;
      
      
      if ($p == 0) {
        __label__ = 21;
        break;
      } else {
        __label__ = 20;
        break;
      }
     case 20:
      
      
      $s = $p + 1;
      __label__ = 6;
      break;
     case 21:
      
      $0 = $obj_addr;
      __label__ = 22;
      break;
     case 22:
      
      $retval = $0;
      var $retval22 = $retval;
      return $retval22;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _attrgetter_call($ag, $args, $kw) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 4;
    _memset(__stackBase__, 0, 4);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $ag_addr;
      var $args_addr;
      var $kw_addr;
      var $retval;
      var $0;
      var $obj = __stackBase__;
      var $result;
      var $i;
      var $nattrs;
      var $attr;
      var $val;
      $ag_addr = $ag;
      $args_addr = $args;
      $kw_addr = $kw;
      
      
      
      $nattrs = HEAP[$ag_addr + 8];
      
      var $5 = _PyArg_UnpackTuple($args_addr, __str220, 1, 1, allocate([ $obj, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($5 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 18;
      break;
     case 2:
      
      
      
      
      
      
      var $13 = HEAP[$ag_addr + 12];
      if (HEAP[$ag_addr + 8] == 1) {
        __label__ = 3;
        break;
      } else {
        __label__ = 4;
        break;
      }
     case 3:
      var $14 = HEAP[$obj];
      var $15 = _dotted_getattr($14, $13);
      $0 = $15;
      __label__ = 18;
      break;
     case 4:
      
      
      
      
      
      
      if ((HEAP[HEAP[$13 + 4] + 84] & 67108864) == 0) {
        __label__ = 5;
        break;
      } else {
        __label__ = 6;
        break;
      }
     case 5:
      ___assert_fail(__str222, __str216, 571, ___PRETTY_FUNCTION___9429);
      throw "Reached an unreachable!";
     case 6:
      
      
      
      
      
      
      
      
      if (HEAP[HEAP[$ag_addr + 12] + 8] != $nattrs) {
        __label__ = 7;
        break;
      } else {
        __label__ = 8;
        break;
      }
     case 7:
      ___assert_fail(__str223, __str216, 572, ___PRETTY_FUNCTION___9429);
      throw "Reached an unreachable!";
     case 8:
      
      var $31 = _PyTuple_New($nattrs);
      $result = $31;
      
      
      if ($result == 0) {
        __label__ = 9;
        break;
      } else {
        __label__ = 10;
        break;
      }
     case 9:
      $0 = 0;
      __label__ = 18;
      break;
     case 10:
      $i = 0;
      __label__ = 16;
      break;
     case 11:
      
      
      
      
      
      
      
      
      $attr = HEAP[HEAP[$ag_addr + 12] + 12 + $i * 4];
      var $42 = HEAP[$obj];
      
      var $44 = _dotted_getattr($42, $attr);
      $val = $44;
      
      
      var $47 = $result;
      if ($val == 0) {
        __label__ = 12;
        break;
      } else {
        __label__ = 15;
        break;
      }
     case 12:
      
      
      var $50 = HEAP[$47] - 1;
      
      
      HEAP[$result] = $50;
      
      
      
      
      if (HEAP[$result] == 0) {
        __label__ = 13;
        break;
      } else {
        __label__ = 14;
        break;
      }
     case 13:
      
      
      
      
      var $61 = HEAP[HEAP[$result + 4] + 24];
      
      FUNCTION_TABLE[$61]($result);
      __label__ = 14;
      break;
     case 14:
      $0 = 0;
      __label__ = 18;
      break;
     case 15:
      
      
      
      
      
      HEAP[$47 + 12 + $i * 4] = $val;
      
      var $69 = $i + 1;
      $i = $69;
      __label__ = 16;
      break;
     case 16:
      
      
      
      if ($i < $nattrs) {
        __label__ = 11;
        break;
      } else {
        __label__ = 17;
        break;
      }
     case 17:
      
      $0 = $result;
      __label__ = 18;
      break;
     case 18:
      
      $retval = $0;
      var $retval18 = $retval;
      STACKTOP = __stackBase__;
      return $retval18;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _methodcaller_new($type, $args, $kwds) {
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $type_addr;
      var $args_addr;
      var $kwds_addr;
      var $retval;
      var $0;
      var $mc;
      var $name;
      var $newargs;
      $type_addr = $type;
      $args_addr = $args;
      $kwds_addr = $kwds;
      
      
      
      
      
      if (HEAP[$args_addr + 8] <= 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      var $6 = HEAP[_PyExc_TypeError];
      _PyErr_SetString($6, __str225);
      $0 = 0;
      __label__ = 11;
      break;
     case 2:
      var $7 = __PyObject_GC_New(_methodcaller_type);
      
      $mc = $7;
      
      
      if ($mc == 0) {
        __label__ = 3;
        break;
      } else {
        __label__ = 4;
        break;
      }
     case 3:
      $0 = 0;
      __label__ = 11;
      break;
     case 4:
      
      
      
      var $14 = HEAP[$args_addr + 8];
      
      var $16 = _PyTuple_GetSlice($args_addr, 1, $14);
      $newargs = $16;
      
      
      var $19 = $mc;
      if ($newargs == 0) {
        __label__ = 5;
        break;
      } else {
        __label__ = 8;
        break;
      }
     case 5:
      
      
      
      var $23 = HEAP[$19] - 1;
      
      HEAP[$19] = $23;
      
      
      
      if (HEAP[$19] == 0) {
        __label__ = 6;
        break;
      } else {
        __label__ = 7;
        break;
      }
     case 6:
      
      
      
      
      
      var $33 = HEAP[HEAP[$mc + 4] + 24];
      
      
      FUNCTION_TABLE[$33]($mc);
      __label__ = 7;
      break;
     case 7:
      $0 = 0;
      __label__ = 11;
      break;
     case 8:
      
      
      HEAP[$19 + 12] = $newargs;
      
      
      
      
      
      $name = HEAP[$args_addr + 12];
      
      
      
      var $46 = HEAP[$name] + 1;
      
      
      HEAP[$name] = $46;
      
      
      
      HEAP[$mc + 8] = $name;
      
      
      if ($kwds_addr != 0) {
        __label__ = 9;
        break;
      } else {
        __label__ = 10;
        break;
      }
     case 9:
      
      
      
      var $57 = HEAP[$kwds_addr] + 1;
      
      
      HEAP[$kwds_addr] = $57;
      __label__ = 10;
      break;
     case 10:
      
      
      
      HEAP[$mc + 16] = $kwds_addr;
      
      
      _PyObject_GC_Track($mc);
      
      
      $0 = $mc;
      __label__ = 11;
      break;
     case 11:
      
      $retval = $0;
      var $retval11 = $retval;
      return $retval11;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _methodcaller_dealloc($mc) {
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $mc_addr;
      $mc_addr = $mc;
      
      
      _PyObject_GC_UnTrack($mc_addr);
      
      
      
      
      if (HEAP[$mc_addr + 8] != 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 3;
        break;
      }
     case 1:
      
      
      var $8 = HEAP[$mc_addr + 8];
      
      
      var $11 = HEAP[$8] - 1;
      var $12 = $8;
      HEAP[$12] = $11;
      
      
      
      if (HEAP[$8] == 0) {
        __label__ = 2;
        break;
      } else {
        __label__ = 3;
        break;
      }
     case 2:
      
      
      
      
      
      
      var $22 = HEAP[HEAP[HEAP[$mc_addr + 8] + 4] + 24];
      
      
      var $25 = HEAP[$mc_addr + 8];
      FUNCTION_TABLE[$22]($25);
      __label__ = 3;
      break;
     case 3:
      
      
      
      
      if (HEAP[$mc_addr + 12] != 0) {
        __label__ = 4;
        break;
      } else {
        __label__ = 6;
        break;
      }
     case 4:
      
      
      var $32 = HEAP[$mc_addr + 12];
      
      
      var $35 = HEAP[$32] - 1;
      var $36 = $32;
      HEAP[$36] = $35;
      
      
      
      if (HEAP[$32] == 0) {
        __label__ = 5;
        break;
      } else {
        __label__ = 6;
        break;
      }
     case 5:
      
      
      
      
      
      
      var $46 = HEAP[HEAP[HEAP[$mc_addr + 12] + 4] + 24];
      
      
      var $49 = HEAP[$mc_addr + 12];
      FUNCTION_TABLE[$46]($49);
      __label__ = 6;
      break;
     case 6:
      
      
      
      
      if (HEAP[$mc_addr + 16] != 0) {
        __label__ = 7;
        break;
      } else {
        __label__ = 9;
        break;
      }
     case 7:
      
      
      var $56 = HEAP[$mc_addr + 16];
      
      
      var $59 = HEAP[$56] - 1;
      var $60 = $56;
      HEAP[$60] = $59;
      
      
      
      if (HEAP[$56] == 0) {
        __label__ = 8;
        break;
      } else {
        __label__ = 9;
        break;
      }
     case 8:
      
      
      
      
      
      
      var $70 = HEAP[HEAP[HEAP[$mc_addr + 16] + 4] + 24];
      
      
      var $73 = HEAP[$mc_addr + 16];
      FUNCTION_TABLE[$70]($73);
      __label__ = 9;
      break;
     case 9:
      
      
      _PyObject_GC_Del($mc_addr);
      return;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _methodcaller_traverse($mc, $visit, $arg) {
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $mc_addr;
      var $visit_addr;
      var $arg_addr;
      var $retval;
      var $0;
      var $vret;
      var $vret4;
      $mc_addr = $mc;
      $visit_addr = $visit;
      $arg_addr = $arg;
      
      
      
      
      if (HEAP[$mc_addr + 12] != 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 3;
        break;
      }
     case 1:
      
      
      var $7 = HEAP[$mc_addr + 12];
      var $8 = $visit_addr;
      
      var $10 = FUNCTION_TABLE[$8]($7, $arg_addr);
      $vret = $10;
      
      
      if ($vret != 0) {
        __label__ = 2;
        break;
      } else {
        __label__ = 3;
        break;
      }
     case 2:
      
      $0 = $vret;
      __label__ = 7;
      break;
     case 3:
      
      
      
      
      if (HEAP[$mc_addr + 16] != 0) {
        __label__ = 4;
        break;
      } else {
        __label__ = 6;
        break;
      }
     case 4:
      
      
      var $20 = HEAP[$mc_addr + 16];
      var $21 = $visit_addr;
      
      var $23 = FUNCTION_TABLE[$21]($20, $arg_addr);
      $vret4 = $23;
      
      
      if ($vret4 != 0) {
        __label__ = 5;
        break;
      } else {
        __label__ = 6;
        break;
      }
     case 5:
      
      $0 = $vret4;
      __label__ = 7;
      break;
     case 6:
      $0 = 0;
      __label__ = 7;
      break;
     case 7:
      
      $retval = $0;
      var $retval8 = $retval;
      return $retval8;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _methodcaller_call($mc, $args, $kw) {
    var __stackBase__ = STACKTOP;
    STACKTOP += 4;
    _memset(__stackBase__, 0, 4);
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $mc_addr;
      var $args_addr;
      var $kw_addr;
      var $retval;
      var $0;
      var $method;
      var $obj = __stackBase__;
      var $result;
      $mc_addr = $mc;
      $args_addr = $args;
      $kw_addr = $kw;
      
      var $2 = _PyArg_UnpackTuple($args_addr, __str226, 1, 1, allocate([ $obj, 0, 0, 0 ], [ "%struct.PyObject**", 0, 0, 0 ], ALLOC_STACK));
      
      if ($2 == 0) {
        __label__ = 1;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 1:
      $0 = 0;
      __label__ = 7;
      break;
     case 2:
      
      
      var $6 = HEAP[$mc_addr + 8];
      var $7 = HEAP[$obj];
      var $8 = _PyObject_GetAttr($7, $6);
      $method = $8;
      
      
      if ($method == 0) {
        __label__ = 3;
        break;
      } else {
        __label__ = 4;
        break;
      }
     case 3:
      $0 = 0;
      __label__ = 7;
      break;
     case 4:
      
      
      var $13 = HEAP[$mc_addr + 16];
      
      
      var $16 = HEAP[$mc_addr + 12];
      
      var $18 = _PyObject_Call($method, $16, $13);
      $result = $18;
      
      
      
      var $22 = HEAP[$method] - 1;
      
      
      HEAP[$method] = $22;
      
      
      
      
      if (HEAP[$method] == 0) {
        __label__ = 5;
        break;
      } else {
        __label__ = 6;
        break;
      }
     case 5:
      
      
      
      
      var $33 = HEAP[HEAP[$method + 4] + 24];
      
      FUNCTION_TABLE[$33]($method);
      __label__ = 6;
      break;
     case 6:
      
      $0 = $result;
      __label__ = 7;
      break;
     case 7:
      
      $retval = $0;
      var $retval7 = $retval;
      STACKTOP = __stackBase__;
      return $retval7;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  function _initoperator() {
    var __label__;
    __label__ = -1;
    while (1) switch (__label__) {
     case -1:
      var $m;
      var $0 = _Py_InitModule4(__str228, _operator_methods, _operator_doc, 0, 1013);
      $m = $0;
      
      
      if ($m == 0) {
        __label__ = 5;
        break;
      } else {
        __label__ = 1;
        break;
      }
     case 1:
      var $3 = _PyType_Ready(_itemgetter_type);
      
      if ($3 < 0) {
        __label__ = 5;
        break;
      } else {
        __label__ = 2;
        break;
      }
     case 2:
      
      var $6 = HEAP[_itemgetter_type] + 1;
      HEAP[_itemgetter_type] = $6;
      
      var $8 = _PyModule_AddObject($m, __str214, _itemgetter_type);
      var $9 = _PyType_Ready(_attrgetter_type);
      
      if ($9 < 0) {
        __label__ = 5;
        break;
      } else {
        __label__ = 3;
        break;
      }
     case 3:
      
      var $12 = HEAP[_attrgetter_type] + 1;
      HEAP[_attrgetter_type] = $12;
      
      var $14 = _PyModule_AddObject($m, __str220, _attrgetter_type);
      var $15 = _PyType_Ready(_methodcaller_type);
      
      if ($15 < 0) {
        __label__ = 5;
        break;
      } else {
        __label__ = 4;
        break;
      }
     case 4:
      
      var $18 = HEAP[_methodcaller_type] + 1;
      HEAP[_methodcaller_type] = $18;
      
      var $20 = _PyModule_AddObject($m, __str226, _methodcaller_type);
      __label__ = 5;
      break;
     case 5:
      return;
     default:
      assert(0, "bad label: " + __label__);
    }
  }
  Module["_initoperator"] = _initoperator;
  FUNCTION_TABLE = FUNCTION_TABLE.concat([ 0, 0, _isCallable, 0, _isNumberType, 0, _isSequenceType, 0, _truth, 0, _op_contains, 0, _sequenceIncludes, 0, _indexOf, 0, _countOf, 0, _isMappingType, 0, _is_, 0, _is_not, 0, _op_index, 0, _op_add, 0, _op_sub, 0, _op_mul, 0, _op_div, 0, _op_floordiv, 0, _op_truediv, 0, _op_mod, 0, _op_neg, 0, _op_pos, 0, _op_abs, 0, _op_inv, 0, _op_invert, 0, _op_lshift, 0, _op_rshift, 0, _op_not_, 0, _op_and_, 0, _op_xor, 0, _op_or_, 0, _op_iadd, 0, _op_isub, 0, _op_imul, 0, _op_idiv, 0, _op_ifloordiv, 0, _op_itruediv, 0, _op_imod, 0, _op_ilshift, 0, _op_irshift, 0, _op_iand, 0, _op_ixor, 0, _op_ior, 0, _op_concat, 0, _op_repeat, 0, _op_iconcat, 0, _op_irepeat, 0, _op_getitem, 0, _op_setitem, 0, _op_delitem, 0, _op_pow, 0, _op_ipow, 0, _op_getslice, 0, _op_setslice, 0, _op_delslice, 0, _op_lt, 0, _op_le, 0, _op_eq, 0, _op_ne, 0, _op_gt, 0, _op_ge, 0, _itemgetter_dealloc, 0, _itemgetter_call, 0, _PyObject_GenericGetAttr, 0, _itemgetter_traverse, 0, _itemgetter_new, 0, _attrgetter_dealloc, 0, _attrgetter_call, 0, _attrgetter_traverse, 0, _attrgetter_new, 0, _methodcaller_dealloc, 0, _methodcaller_call, 0, _methodcaller_traverse, 0, _methodcaller_new, 0 ]);
  function run(args) {
    _operator_doc = allocate([ 79, 112, 101, 114, 97, 116, 111, 114, 32, 105, 110, 116, 101, 114, 102, 97, 99, 101, 46, 10, 10, 84, 104, 105, 115, 32, 109, 111, 100, 117, 108, 101, 32, 101, 120, 112, 111, 114, 116, 115, 32, 97, 32, 115, 101, 116, 32, 111, 102, 32, 102, 117, 110, 99, 116, 105, 111, 110, 115, 32, 105, 109, 112, 108, 101, 109, 101, 110, 116, 101, 100, 32, 105, 110, 32, 67, 32, 99, 111, 114, 114, 101, 115, 112, 111, 110, 100, 105, 110, 103, 10, 116, 111, 32, 116, 104, 101, 32, 105, 110, 116, 114, 105, 110, 115, 105, 99, 32, 111, 112, 101, 114, 97, 116, 111, 114, 115, 32, 111, 102, 32, 80, 121, 116, 104, 111, 110, 46, 32, 32, 70, 111, 114, 32, 101, 120, 97, 109, 112, 108, 101, 44, 32, 111, 112, 101, 114, 97, 116, 111, 114, 46, 97, 100, 100, 40, 120, 44, 32, 121, 41, 10, 105, 115, 32, 101, 113, 117, 105, 118, 97, 108, 101, 110, 116, 32, 116, 111, 32, 116, 104, 101, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 120, 43, 121, 46, 32, 32, 84, 104, 101, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 110, 97, 109, 101, 115, 32, 97, 114, 101, 32, 116, 104, 111, 115, 101, 10, 117, 115, 101, 100, 32, 102, 111, 114, 32, 115, 112, 101, 99, 105, 97, 108, 32, 109, 101, 116, 104, 111, 100, 115, 59, 32, 118, 97, 114, 105, 97, 110, 116, 115, 32, 119, 105, 116, 104, 111, 117, 116, 32, 108, 101, 97, 100, 105, 110, 103, 32, 97, 110, 100, 32, 116, 114, 97, 105, 108, 105, 110, 103, 10, 39, 95, 95, 39, 32, 97, 114, 101, 32, 97, 108, 115, 111, 32, 112, 114, 111, 118, 105, 100, 101, 100, 32, 102, 111, 114, 32, 99, 111, 110, 118, 101, 110, 105, 101, 110, 99, 101, 46, 0 ], "i8", ALLOC_NORMAL);
    __str = allocate([ 111, 112, 101, 114, 97, 116, 111, 114, 46, 105, 115, 67, 97, 108, 108, 97, 98, 108, 101, 40, 41, 32, 105, 115, 32, 110, 111, 116, 32, 115, 117, 112, 112, 111, 114, 116, 101, 100, 32, 105, 110, 32, 51, 46, 120, 46, 32, 85, 115, 101, 32, 104, 97, 115, 97, 116, 116, 114, 40, 111, 98, 106, 44, 32, 39, 95, 95, 99, 97, 108, 108, 95, 95, 39, 41, 46, 0 ], "i8", ALLOC_NORMAL);
    __str1 = allocate([ 111, 112, 101, 114, 97, 116, 111, 114, 46, 115, 101, 113, 117, 101, 110, 99, 101, 73, 110, 99, 108, 117, 100, 101, 115, 40, 41, 32, 105, 115, 32, 110, 111, 116, 32, 115, 117, 112, 112, 111, 114, 116, 101, 100, 32, 105, 110, 32, 51, 46, 120, 46, 32, 85, 115, 101, 32, 111, 112, 101, 114, 97, 116, 111, 114, 46, 99, 111, 110, 116, 97, 105, 110, 115, 40, 41, 46, 0 ], "i8", ALLOC_NORMAL);
    __str2 = allocate([ 111, 112, 95, 97, 100, 100, 0 ], "i8", ALLOC_NORMAL);
    __str3 = allocate([ 111, 112, 95, 115, 117, 98, 0 ], "i8", ALLOC_NORMAL);
    __str4 = allocate([ 111, 112, 95, 109, 117, 108, 0 ], "i8", ALLOC_NORMAL);
    __str5 = allocate([ 111, 112, 95, 100, 105, 118, 0 ], "i8", ALLOC_NORMAL);
    __str6 = allocate([ 111, 112, 95, 102, 108, 111, 111, 114, 100, 105, 118, 0 ], "i8", ALLOC_NORMAL);
    __str7 = allocate([ 111, 112, 95, 116, 114, 117, 101, 100, 105, 118, 0 ], "i8", ALLOC_NORMAL);
    __str8 = allocate([ 111, 112, 95, 109, 111, 100, 0 ], "i8", ALLOC_NORMAL);
    __str9 = allocate([ 111, 112, 95, 108, 115, 104, 105, 102, 116, 0 ], "i8", ALLOC_NORMAL);
    __str10 = allocate([ 111, 112, 95, 114, 115, 104, 105, 102, 116, 0 ], "i8", ALLOC_NORMAL);
    __str11 = allocate([ 111, 112, 95, 97, 110, 100, 95, 0 ], "i8", ALLOC_NORMAL);
    __str12 = allocate([ 111, 112, 95, 120, 111, 114, 0 ], "i8", ALLOC_NORMAL);
    __str13 = allocate([ 111, 112, 95, 111, 114, 95, 0 ], "i8", ALLOC_NORMAL);
    __str14 = allocate([ 111, 112, 95, 105, 97, 100, 100, 0 ], "i8", ALLOC_NORMAL);
    __str15 = allocate([ 111, 112, 95, 105, 115, 117, 98, 0 ], "i8", ALLOC_NORMAL);
    __str16 = allocate([ 111, 112, 95, 105, 109, 117, 108, 0 ], "i8", ALLOC_NORMAL);
    __str17 = allocate([ 111, 112, 95, 105, 100, 105, 118, 0 ], "i8", ALLOC_NORMAL);
    __str18 = allocate([ 111, 112, 95, 105, 102, 108, 111, 111, 114, 100, 105, 118, 0 ], "i8", ALLOC_NORMAL);
    __str19 = allocate([ 111, 112, 95, 105, 116, 114, 117, 101, 100, 105, 118, 0 ], "i8", ALLOC_NORMAL);
    __str20 = allocate([ 111, 112, 95, 105, 109, 111, 100, 0 ], "i8", ALLOC_NORMAL);
    __str21 = allocate([ 111, 112, 95, 105, 108, 115, 104, 105, 102, 116, 0 ], "i8", ALLOC_NORMAL);
    __str22 = allocate([ 111, 112, 95, 105, 114, 115, 104, 105, 102, 116, 0 ], "i8", ALLOC_NORMAL);
    __str23 = allocate([ 111, 112, 95, 105, 97, 110, 100, 0 ], "i8", ALLOC_NORMAL);
    __str24 = allocate([ 111, 112, 95, 105, 120, 111, 114, 0 ], "i8", ALLOC_NORMAL);
    __str25 = allocate([ 111, 112, 95, 105, 111, 114, 0 ], "i8", ALLOC_NORMAL);
    __str26 = allocate([ 111, 112, 95, 99, 111, 110, 99, 97, 116, 0 ], "i8", ALLOC_NORMAL);
    __str27 = allocate([ 79, 105, 58, 111, 112, 95, 114, 101, 112, 101, 97, 116, 0 ], "i8", ALLOC_NORMAL);
    __str28 = allocate([ 111, 112, 95, 105, 99, 111, 110, 99, 97, 116, 0 ], "i8", ALLOC_NORMAL);
    __str29 = allocate([ 79, 105, 58, 111, 112, 95, 105, 114, 101, 112, 101, 97, 116, 0 ], "i8", ALLOC_NORMAL);
    __str30 = allocate([ 111, 112, 95, 99, 111, 110, 116, 97, 105, 110, 115, 0 ], "i8", ALLOC_NORMAL);
    __str31 = allocate([ 115, 101, 113, 117, 101, 110, 99, 101, 73, 110, 99, 108, 117, 100, 101, 115, 0 ], "i8", ALLOC_NORMAL);
    __str32 = allocate([ 105, 110, 100, 101, 120, 79, 102, 0 ], "i8", ALLOC_NORMAL);
    __str33 = allocate([ 99, 111, 117, 110, 116, 79, 102, 0 ], "i8", ALLOC_NORMAL);
    __str34 = allocate([ 111, 112, 95, 103, 101, 116, 105, 116, 101, 109, 0 ], "i8", ALLOC_NORMAL);
    __str35 = allocate([ 111, 112, 95, 100, 101, 108, 105, 116, 101, 109, 0 ], "i8", ALLOC_NORMAL);
    __str36 = allocate([ 111, 112, 95, 115, 101, 116, 105, 116, 101, 109, 0 ], "i8", ALLOC_NORMAL);
    __str37 = allocate([ 111, 112, 95, 108, 116, 0 ], "i8", ALLOC_NORMAL);
    __str38 = allocate([ 111, 112, 95, 108, 101, 0 ], "i8", ALLOC_NORMAL);
    __str39 = allocate([ 111, 112, 95, 101, 113, 0 ], "i8", ALLOC_NORMAL);
    __str40 = allocate([ 111, 112, 95, 110, 101, 0 ], "i8", ALLOC_NORMAL);
    __str41 = allocate([ 111, 112, 95, 103, 116, 0 ], "i8", ALLOC_NORMAL);
    __str42 = allocate([ 111, 112, 95, 103, 101, 0 ], "i8", ALLOC_NORMAL);
    __str43 = allocate([ 112, 111, 119, 0 ], "i8", ALLOC_NORMAL);
    __str44 = allocate([ 105, 112, 111, 119, 0 ], "i8", ALLOC_NORMAL);
    __str45 = allocate([ 105, 115, 95, 0 ], "i8", ALLOC_NORMAL);
    __str46 = allocate([ 105, 115, 95, 110, 111, 116, 0 ], "i8", ALLOC_NORMAL);
    __str47 = allocate([ 79, 110, 110, 58, 103, 101, 116, 115, 108, 105, 99, 101, 0 ], "i8", ALLOC_NORMAL);
    __str48 = allocate([ 79, 110, 110, 79, 58, 115, 101, 116, 115, 108, 105, 99, 101, 0 ], "i8", ALLOC_NORMAL);
    __str49 = allocate([ 79, 110, 110, 58, 100, 101, 108, 115, 108, 105, 99, 101, 0 ], "i8", ALLOC_NORMAL);
    __str50 = allocate([ 105, 115, 67, 97, 108, 108, 97, 98, 108, 101, 0 ], "i8", ALLOC_NORMAL);
    __str51 = allocate([ 105, 115, 67, 97, 108, 108, 97, 98, 108, 101, 40, 97, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 99, 97, 108, 108, 97, 98, 108, 101, 40, 97, 41, 46, 0 ], "i8", ALLOC_NORMAL);
    __str52 = allocate([ 105, 115, 78, 117, 109, 98, 101, 114, 84, 121, 112, 101, 0 ], "i8", ALLOC_NORMAL);
    __str53 = allocate([ 105, 115, 78, 117, 109, 98, 101, 114, 84, 121, 112, 101, 40, 97, 41, 32, 45, 45, 32, 82, 101, 116, 117, 114, 110, 32, 84, 114, 117, 101, 32, 105, 102, 32, 97, 32, 104, 97, 115, 32, 97, 32, 110, 117, 109, 101, 114, 105, 99, 32, 116, 121, 112, 101, 44, 32, 70, 97, 108, 115, 101, 32, 111, 116, 104, 101, 114, 119, 105, 115, 101, 46, 0 ], "i8", ALLOC_NORMAL);
    __str54 = allocate([ 105, 115, 83, 101, 113, 117, 101, 110, 99, 101, 84, 121, 112, 101, 0 ], "i8", ALLOC_NORMAL);
    __str55 = allocate([ 105, 115, 83, 101, 113, 117, 101, 110, 99, 101, 84, 121, 112, 101, 40, 97, 41, 32, 45, 45, 32, 82, 101, 116, 117, 114, 110, 32, 84, 114, 117, 101, 32, 105, 102, 32, 97, 32, 104, 97, 115, 32, 97, 32, 115, 101, 113, 117, 101, 110, 99, 101, 32, 116, 121, 112, 101, 44, 32, 70, 97, 108, 115, 101, 32, 111, 116, 104, 101, 114, 119, 105, 115, 101, 46, 0 ], "i8", ALLOC_NORMAL);
    __str56 = allocate([ 116, 114, 117, 116, 104, 0 ], "i8", ALLOC_NORMAL);
    __str57 = allocate([ 116, 114, 117, 116, 104, 40, 97, 41, 32, 45, 45, 32, 82, 101, 116, 117, 114, 110, 32, 84, 114, 117, 101, 32, 105, 102, 32, 97, 32, 105, 115, 32, 116, 114, 117, 101, 44, 32, 70, 97, 108, 115, 101, 32, 111, 116, 104, 101, 114, 119, 105, 115, 101, 46, 0 ], "i8", ALLOC_NORMAL);
    __str58 = allocate([ 99, 111, 110, 116, 97, 105, 110, 115, 0 ], "i8", ALLOC_NORMAL);
    __str59 = allocate([ 99, 111, 110, 116, 97, 105, 110, 115, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 98, 32, 105, 110, 32, 97, 32, 40, 110, 111, 116, 101, 32, 114, 101, 118, 101, 114, 115, 101, 100, 32, 111, 112, 101, 114, 97, 110, 100, 115, 41, 46, 0 ], "i8", ALLOC_NORMAL);
    __str60 = allocate([ 95, 95, 99, 111, 110, 116, 97, 105, 110, 115, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str61 = allocate([ 115, 101, 113, 117, 101, 110, 99, 101, 73, 110, 99, 108, 117, 100, 101, 115, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 98, 32, 105, 110, 32, 97, 32, 40, 110, 111, 116, 101, 32, 114, 101, 118, 101, 114, 115, 101, 100, 32, 111, 112, 101, 114, 97, 110, 100, 115, 59, 32, 100, 101, 112, 114, 101, 99, 97, 116, 101, 100, 41, 46, 0 ], "i8", ALLOC_NORMAL);
    __str62 = allocate([ 105, 110, 100, 101, 120, 79, 102, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 82, 101, 116, 117, 114, 110, 32, 116, 104, 101, 32, 102, 105, 114, 115, 116, 32, 105, 110, 100, 101, 120, 32, 111, 102, 32, 98, 32, 105, 110, 32, 97, 46, 0 ], "i8", ALLOC_NORMAL);
    __str63 = allocate([ 99, 111, 117, 110, 116, 79, 102, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 82, 101, 116, 117, 114, 110, 32, 116, 104, 101, 32, 110, 117, 109, 98, 101, 114, 32, 111, 102, 32, 116, 105, 109, 101, 115, 32, 98, 32, 111, 99, 99, 117, 114, 115, 32, 105, 110, 32, 97, 46, 0 ], "i8", ALLOC_NORMAL);
    __str64 = allocate([ 105, 115, 77, 97, 112, 112, 105, 110, 103, 84, 121, 112, 101, 0 ], "i8", ALLOC_NORMAL);
    __str65 = allocate([ 105, 115, 77, 97, 112, 112, 105, 110, 103, 84, 121, 112, 101, 40, 97, 41, 32, 45, 45, 32, 82, 101, 116, 117, 114, 110, 32, 84, 114, 117, 101, 32, 105, 102, 32, 97, 32, 104, 97, 115, 32, 97, 32, 109, 97, 112, 112, 105, 110, 103, 32, 116, 121, 112, 101, 44, 32, 70, 97, 108, 115, 101, 32, 111, 116, 104, 101, 114, 119, 105, 115, 101, 46, 0 ], "i8", ALLOC_NORMAL);
    __str66 = allocate([ 105, 115, 95, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 105, 115, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str67 = allocate([ 105, 115, 95, 110, 111, 116, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 105, 115, 32, 110, 111, 116, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str68 = allocate([ 105, 110, 100, 101, 120, 0 ], "i8", ALLOC_NORMAL);
    __str69 = allocate([ 105, 110, 100, 101, 120, 40, 97, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 46, 95, 95, 105, 110, 100, 101, 120, 95, 95, 40, 41, 0 ], "i8", ALLOC_NORMAL);
    __str70 = allocate([ 95, 95, 105, 110, 100, 101, 120, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str71 = allocate([ 97, 100, 100, 0 ], "i8", ALLOC_NORMAL);
    __str72 = allocate([ 97, 100, 100, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 43, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str73 = allocate([ 95, 95, 97, 100, 100, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str74 = allocate([ 115, 117, 98, 0 ], "i8", ALLOC_NORMAL);
    __str75 = allocate([ 115, 117, 98, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 45, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str76 = allocate([ 95, 95, 115, 117, 98, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str77 = allocate([ 109, 117, 108, 0 ], "i8", ALLOC_NORMAL);
    __str78 = allocate([ 109, 117, 108, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 42, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str79 = allocate([ 95, 95, 109, 117, 108, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str80 = allocate([ 100, 105, 118, 0 ], "i8", ALLOC_NORMAL);
    __str81 = allocate([ 100, 105, 118, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 47, 32, 98, 32, 119, 104, 101, 110, 32, 95, 95, 102, 117, 116, 117, 114, 101, 95, 95, 46, 100, 105, 118, 105, 115, 105, 111, 110, 32, 105, 115, 32, 110, 111, 116, 32, 105, 110, 32, 101, 102, 102, 101, 99, 116, 46, 0 ], "i8", ALLOC_NORMAL);
    __str82 = allocate([ 95, 95, 100, 105, 118, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str83 = allocate([ 102, 108, 111, 111, 114, 100, 105, 118, 0 ], "i8", ALLOC_NORMAL);
    __str84 = allocate([ 102, 108, 111, 111, 114, 100, 105, 118, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 47, 47, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str85 = allocate([ 95, 95, 102, 108, 111, 111, 114, 100, 105, 118, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str86 = allocate([ 116, 114, 117, 101, 100, 105, 118, 0 ], "i8", ALLOC_NORMAL);
    __str87 = allocate([ 116, 114, 117, 101, 100, 105, 118, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 47, 32, 98, 32, 119, 104, 101, 110, 32, 95, 95, 102, 117, 116, 117, 114, 101, 95, 95, 46, 100, 105, 118, 105, 115, 105, 111, 110, 32, 105, 115, 32, 105, 110, 32, 101, 102, 102, 101, 99, 116, 46, 0 ], "i8", ALLOC_NORMAL);
    __str88 = allocate([ 95, 95, 116, 114, 117, 101, 100, 105, 118, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str89 = allocate([ 109, 111, 100, 0 ], "i8", ALLOC_NORMAL);
    __str90 = allocate([ 109, 111, 100, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 37, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str91 = allocate([ 95, 95, 109, 111, 100, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str92 = allocate([ 110, 101, 103, 0 ], "i8", ALLOC_NORMAL);
    __str93 = allocate([ 110, 101, 103, 40, 97, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 45, 97, 46, 0 ], "i8", ALLOC_NORMAL);
    __str94 = allocate([ 95, 95, 110, 101, 103, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str95 = allocate([ 112, 111, 115, 0 ], "i8", ALLOC_NORMAL);
    __str96 = allocate([ 112, 111, 115, 40, 97, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 43, 97, 46, 0 ], "i8", ALLOC_NORMAL);
    __str97 = allocate([ 95, 95, 112, 111, 115, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str98 = allocate([ 97, 98, 115, 0 ], "i8", ALLOC_NORMAL);
    __str99 = allocate([ 97, 98, 115, 40, 97, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 98, 115, 40, 97, 41, 46, 0 ], "i8", ALLOC_NORMAL);
    __str100 = allocate([ 95, 95, 97, 98, 115, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str101 = allocate([ 105, 110, 118, 0 ], "i8", ALLOC_NORMAL);
    __str102 = allocate([ 105, 110, 118, 40, 97, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 126, 97, 46, 0 ], "i8", ALLOC_NORMAL);
    __str103 = allocate([ 95, 95, 105, 110, 118, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str104 = allocate([ 105, 110, 118, 101, 114, 116, 0 ], "i8", ALLOC_NORMAL);
    __str105 = allocate([ 105, 110, 118, 101, 114, 116, 40, 97, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 126, 97, 46, 0 ], "i8", ALLOC_NORMAL);
    __str106 = allocate([ 95, 95, 105, 110, 118, 101, 114, 116, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str107 = allocate([ 108, 115, 104, 105, 102, 116, 0 ], "i8", ALLOC_NORMAL);
    __str108 = allocate([ 108, 115, 104, 105, 102, 116, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 60, 60, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str109 = allocate([ 95, 95, 108, 115, 104, 105, 102, 116, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str110 = allocate([ 114, 115, 104, 105, 102, 116, 0 ], "i8", ALLOC_NORMAL);
    __str111 = allocate([ 114, 115, 104, 105, 102, 116, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 62, 62, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str112 = allocate([ 95, 95, 114, 115, 104, 105, 102, 116, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str113 = allocate([ 110, 111, 116, 95, 0 ], "i8", ALLOC_NORMAL);
    __str114 = allocate([ 110, 111, 116, 95, 40, 97, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 110, 111, 116, 32, 97, 46, 0 ], "i8", ALLOC_NORMAL);
    __str115 = allocate([ 95, 95, 110, 111, 116, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str116 = allocate([ 97, 110, 100, 95, 0 ], "i8", ALLOC_NORMAL);
    __str117 = allocate([ 97, 110, 100, 95, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 38, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str118 = allocate([ 95, 95, 97, 110, 100, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str119 = allocate([ 120, 111, 114, 0 ], "i8", ALLOC_NORMAL);
    __str120 = allocate([ 120, 111, 114, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 94, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str121 = allocate([ 95, 95, 120, 111, 114, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str122 = allocate([ 111, 114, 95, 0 ], "i8", ALLOC_NORMAL);
    __str123 = allocate([ 111, 114, 95, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 124, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str124 = allocate([ 95, 95, 111, 114, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str125 = allocate([ 105, 97, 100, 100, 0 ], "i8", ALLOC_NORMAL);
    __str126 = allocate([ 97, 32, 61, 32, 105, 97, 100, 100, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 43, 61, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str127 = allocate([ 95, 95, 105, 97, 100, 100, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str128 = allocate([ 105, 115, 117, 98, 0 ], "i8", ALLOC_NORMAL);
    __str129 = allocate([ 97, 32, 61, 32, 105, 115, 117, 98, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 45, 61, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str130 = allocate([ 95, 95, 105, 115, 117, 98, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str131 = allocate([ 105, 109, 117, 108, 0 ], "i8", ALLOC_NORMAL);
    __str132 = allocate([ 97, 32, 61, 32, 105, 109, 117, 108, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 42, 61, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str133 = allocate([ 95, 95, 105, 109, 117, 108, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str134 = allocate([ 105, 100, 105, 118, 0 ], "i8", ALLOC_NORMAL);
    __str135 = allocate([ 97, 32, 61, 32, 105, 100, 105, 118, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 47, 61, 32, 98, 32, 119, 104, 101, 110, 32, 95, 95, 102, 117, 116, 117, 114, 101, 95, 95, 46, 100, 105, 118, 105, 115, 105, 111, 110, 32, 105, 115, 32, 110, 111, 116, 32, 105, 110, 32, 101, 102, 102, 101, 99, 116, 46, 0 ], "i8", ALLOC_NORMAL);
    __str136 = allocate([ 95, 95, 105, 100, 105, 118, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str137 = allocate([ 105, 102, 108, 111, 111, 114, 100, 105, 118, 0 ], "i8", ALLOC_NORMAL);
    __str138 = allocate([ 97, 32, 61, 32, 105, 102, 108, 111, 111, 114, 100, 105, 118, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 47, 47, 61, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str139 = allocate([ 95, 95, 105, 102, 108, 111, 111, 114, 100, 105, 118, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str140 = allocate([ 105, 116, 114, 117, 101, 100, 105, 118, 0 ], "i8", ALLOC_NORMAL);
    __str141 = allocate([ 97, 32, 61, 32, 105, 116, 114, 117, 101, 100, 105, 118, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 47, 61, 32, 98, 32, 119, 104, 101, 110, 32, 95, 95, 102, 117, 116, 117, 114, 101, 95, 95, 46, 100, 105, 118, 105, 115, 105, 111, 110, 32, 105, 115, 32, 105, 110, 32, 101, 102, 102, 101, 99, 116, 46, 0 ], "i8", ALLOC_NORMAL);
    __str142 = allocate([ 95, 95, 105, 116, 114, 117, 101, 100, 105, 118, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str143 = allocate([ 105, 109, 111, 100, 0 ], "i8", ALLOC_NORMAL);
    __str144 = allocate([ 97, 32, 61, 32, 105, 109, 111, 100, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 37, 61, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str145 = allocate([ 95, 95, 105, 109, 111, 100, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str146 = allocate([ 105, 108, 115, 104, 105, 102, 116, 0 ], "i8", ALLOC_NORMAL);
    __str147 = allocate([ 97, 32, 61, 32, 105, 108, 115, 104, 105, 102, 116, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 60, 60, 61, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str148 = allocate([ 95, 95, 105, 108, 115, 104, 105, 102, 116, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str149 = allocate([ 105, 114, 115, 104, 105, 102, 116, 0 ], "i8", ALLOC_NORMAL);
    __str150 = allocate([ 97, 32, 61, 32, 105, 114, 115, 104, 105, 102, 116, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 62, 62, 61, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str151 = allocate([ 95, 95, 105, 114, 115, 104, 105, 102, 116, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str152 = allocate([ 105, 97, 110, 100, 0 ], "i8", ALLOC_NORMAL);
    __str153 = allocate([ 97, 32, 61, 32, 105, 97, 110, 100, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 38, 61, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str154 = allocate([ 95, 95, 105, 97, 110, 100, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str155 = allocate([ 105, 120, 111, 114, 0 ], "i8", ALLOC_NORMAL);
    __str156 = allocate([ 97, 32, 61, 32, 105, 120, 111, 114, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 94, 61, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str157 = allocate([ 95, 95, 105, 120, 111, 114, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str158 = allocate([ 105, 111, 114, 0 ], "i8", ALLOC_NORMAL);
    __str159 = allocate([ 97, 32, 61, 32, 105, 111, 114, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 124, 61, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str160 = allocate([ 95, 95, 105, 111, 114, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str161 = allocate([ 99, 111, 110, 99, 97, 116, 0 ], "i8", ALLOC_NORMAL);
    __str162 = allocate([ 99, 111, 110, 99, 97, 116, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 43, 32, 98, 44, 32, 102, 111, 114, 32, 97, 32, 97, 110, 100, 32, 98, 32, 115, 101, 113, 117, 101, 110, 99, 101, 115, 46, 0 ], "i8", ALLOC_NORMAL);
    __str163 = allocate([ 95, 95, 99, 111, 110, 99, 97, 116, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str164 = allocate([ 114, 101, 112, 101, 97, 116, 0 ], "i8", ALLOC_NORMAL);
    __str165 = allocate([ 114, 101, 112, 101, 97, 116, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 82, 101, 116, 117, 114, 110, 32, 97, 32, 42, 32, 98, 44, 32, 119, 104, 101, 114, 101, 32, 97, 32, 105, 115, 32, 97, 32, 115, 101, 113, 117, 101, 110, 99, 101, 44, 32, 97, 110, 100, 32, 98, 32, 105, 115, 32, 97, 110, 32, 105, 110, 116, 101, 103, 101, 114, 46, 0 ], "i8", ALLOC_NORMAL);
    __str166 = allocate([ 95, 95, 114, 101, 112, 101, 97, 116, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str167 = allocate([ 105, 99, 111, 110, 99, 97, 116, 0 ], "i8", ALLOC_NORMAL);
    __str168 = allocate([ 97, 32, 61, 32, 105, 99, 111, 110, 99, 97, 116, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 43, 61, 32, 98, 44, 32, 102, 111, 114, 32, 97, 32, 97, 110, 100, 32, 98, 32, 115, 101, 113, 117, 101, 110, 99, 101, 115, 46, 0 ], "i8", ALLOC_NORMAL);
    __str169 = allocate([ 95, 95, 105, 99, 111, 110, 99, 97, 116, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str170 = allocate([ 105, 114, 101, 112, 101, 97, 116, 0 ], "i8", ALLOC_NORMAL);
    __str171 = allocate([ 97, 32, 61, 32, 105, 114, 101, 112, 101, 97, 116, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 42, 61, 32, 98, 44, 32, 119, 104, 101, 114, 101, 32, 97, 32, 105, 115, 32, 97, 32, 115, 101, 113, 117, 101, 110, 99, 101, 44, 32, 97, 110, 100, 32, 98, 32, 105, 115, 32, 97, 110, 32, 105, 110, 116, 101, 103, 101, 114, 46, 0 ], "i8", ALLOC_NORMAL);
    __str172 = allocate([ 95, 95, 105, 114, 101, 112, 101, 97, 116, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str173 = allocate([ 103, 101, 116, 105, 116, 101, 109, 0 ], "i8", ALLOC_NORMAL);
    __str174 = allocate([ 103, 101, 116, 105, 116, 101, 109, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 91, 98, 93, 46, 0 ], "i8", ALLOC_NORMAL);
    __str175 = allocate([ 95, 95, 103, 101, 116, 105, 116, 101, 109, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str176 = allocate([ 115, 101, 116, 105, 116, 101, 109, 0 ], "i8", ALLOC_NORMAL);
    __str177 = allocate([ 115, 101, 116, 105, 116, 101, 109, 40, 97, 44, 32, 98, 44, 32, 99, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 91, 98, 93, 32, 61, 32, 99, 46, 0 ], "i8", ALLOC_NORMAL);
    __str178 = allocate([ 95, 95, 115, 101, 116, 105, 116, 101, 109, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str179 = allocate([ 100, 101, 108, 105, 116, 101, 109, 0 ], "i8", ALLOC_NORMAL);
    __str180 = allocate([ 100, 101, 108, 105, 116, 101, 109, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 100, 101, 108, 32, 97, 91, 98, 93, 46, 0 ], "i8", ALLOC_NORMAL);
    __str181 = allocate([ 95, 95, 100, 101, 108, 105, 116, 101, 109, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str182 = allocate([ 112, 111, 119, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 42, 42, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str183 = allocate([ 95, 95, 112, 111, 119, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str184 = allocate([ 97, 32, 61, 32, 105, 112, 111, 119, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 32, 42, 42, 61, 32, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str185 = allocate([ 95, 95, 105, 112, 111, 119, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str186 = allocate([ 103, 101, 116, 115, 108, 105, 99, 101, 0 ], "i8", ALLOC_NORMAL);
    __str187 = allocate([ 103, 101, 116, 115, 108, 105, 99, 101, 40, 97, 44, 32, 98, 44, 32, 99, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 91, 98, 58, 99, 93, 46, 0 ], "i8", ALLOC_NORMAL);
    __str188 = allocate([ 95, 95, 103, 101, 116, 115, 108, 105, 99, 101, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str189 = allocate([ 115, 101, 116, 115, 108, 105, 99, 101, 0 ], "i8", ALLOC_NORMAL);
    __str190 = allocate([ 115, 101, 116, 115, 108, 105, 99, 101, 40, 97, 44, 32, 98, 44, 32, 99, 44, 32, 100, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 91, 98, 58, 99, 93, 32, 61, 32, 100, 46, 0 ], "i8", ALLOC_NORMAL);
    __str191 = allocate([ 95, 95, 115, 101, 116, 115, 108, 105, 99, 101, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str192 = allocate([ 100, 101, 108, 115, 108, 105, 99, 101, 0 ], "i8", ALLOC_NORMAL);
    __str193 = allocate([ 100, 101, 108, 115, 108, 105, 99, 101, 40, 97, 44, 32, 98, 44, 32, 99, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 100, 101, 108, 32, 97, 91, 98, 58, 99, 93, 46, 0 ], "i8", ALLOC_NORMAL);
    __str194 = allocate([ 95, 95, 100, 101, 108, 115, 108, 105, 99, 101, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str195 = allocate([ 108, 116, 0 ], "i8", ALLOC_NORMAL);
    __str196 = allocate([ 108, 116, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 60, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str197 = allocate([ 95, 95, 108, 116, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str198 = allocate([ 108, 101, 0 ], "i8", ALLOC_NORMAL);
    __str199 = allocate([ 108, 101, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 60, 61, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str200 = allocate([ 95, 95, 108, 101, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str201 = allocate([ 101, 113, 0 ], "i8", ALLOC_NORMAL);
    __str202 = allocate([ 101, 113, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 61, 61, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str203 = allocate([ 95, 95, 101, 113, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str204 = allocate([ 110, 101, 0 ], "i8", ALLOC_NORMAL);
    __str205 = allocate([ 110, 101, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 33, 61, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str206 = allocate([ 95, 95, 110, 101, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str207 = allocate([ 103, 116, 0 ], "i8", ALLOC_NORMAL);
    __str208 = allocate([ 103, 116, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 62, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str209 = allocate([ 95, 95, 103, 116, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    __str210 = allocate([ 103, 101, 0 ], "i8", ALLOC_NORMAL);
    __str211 = allocate([ 103, 101, 40, 97, 44, 32, 98, 41, 32, 45, 45, 32, 83, 97, 109, 101, 32, 97, 115, 32, 97, 62, 61, 98, 46, 0 ], "i8", ALLOC_NORMAL);
    __str212 = allocate([ 95, 95, 103, 101, 95, 95, 0 ], "i8", ALLOC_NORMAL);
    _operator_methods = allocate([ 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ], [ "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i8*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8" ], ALLOC_NORMAL);
    __str213 = allocate([ 105, 116, 101, 109, 103, 101, 116, 116, 101, 114, 40, 41, 0 ], "i8", ALLOC_NORMAL);
    __str214 = allocate([ 105, 116, 101, 109, 103, 101, 116, 116, 101, 114, 0 ], "i8", ALLOC_NORMAL);
    __str215 = allocate([ 40, 40, 40, 40, 40, 40, 80, 121, 79, 98, 106, 101, 99, 116, 42, 41, 40, 105, 103, 45, 62, 105, 116, 101, 109, 41, 41, 45, 62, 111, 98, 95, 116, 121, 112, 101, 41, 41, 45, 62, 116, 112, 95, 102, 108, 97, 103, 115, 32, 38, 32, 40, 40, 49, 76, 60, 60, 50, 54, 41, 41, 41, 32, 33, 61, 32, 48, 41, 0 ], "i8", ALLOC_NORMAL);
    __str216 = allocate([ 46, 46, 47, 99, 112, 121, 116, 104, 111, 110, 47, 77, 111, 100, 117, 108, 101, 115, 47, 111, 112, 101, 114, 97, 116, 111, 114, 46, 99, 0 ], "i8", ALLOC_NORMAL);
    ___PRETTY_FUNCTION___9242 = allocate([ 105, 116, 101, 109, 103, 101, 116, 116, 101, 114, 95, 99, 97, 108, 108, 0 ], "i8", ALLOC_NORMAL);
    __str217 = allocate([ 40, 40, 40, 80, 121, 86, 97, 114, 79, 98, 106, 101, 99, 116, 42, 41, 40, 105, 103, 45, 62, 105, 116, 101, 109, 41, 41, 45, 62, 111, 98, 95, 115, 105, 122, 101, 41, 32, 61, 61, 32, 110, 105, 116, 101, 109, 115, 0 ], "i8", ALLOC_NORMAL);
    _itemgetter_doc = allocate([ 105, 116, 101, 109, 103, 101, 116, 116, 101, 114, 40, 105, 116, 101, 109, 44, 32, 46, 46, 46, 41, 32, 45, 45, 62, 32, 105, 116, 101, 109, 103, 101, 116, 116, 101, 114, 32, 111, 98, 106, 101, 99, 116, 10, 10, 82, 101, 116, 117, 114, 110, 32, 97, 32, 99, 97, 108, 108, 97, 98, 108, 101, 32, 111, 98, 106, 101, 99, 116, 32, 116, 104, 97, 116, 32, 102, 101, 116, 99, 104, 101, 115, 32, 116, 104, 101, 32, 103, 105, 118, 101, 110, 32, 105, 116, 101, 109, 40, 115, 41, 32, 102, 114, 111, 109, 32, 105, 116, 115, 32, 111, 112, 101, 114, 97, 110, 100, 46, 10, 65, 102, 116, 101, 114, 44, 32, 102, 61, 105, 116, 101, 109, 103, 101, 116, 116, 101, 114, 40, 50, 41, 44, 32, 116, 104, 101, 32, 99, 97, 108, 108, 32, 102, 40, 114, 41, 32, 114, 101, 116, 117, 114, 110, 115, 32, 114, 91, 50, 93, 46, 10, 65, 102, 116, 101, 114, 44, 32, 103, 61, 105, 116, 101, 109, 103, 101, 116, 116, 101, 114, 40, 50, 44, 53, 44, 51, 41, 44, 32, 116, 104, 101, 32, 99, 97, 108, 108, 32, 103, 40, 114, 41, 32, 114, 101, 116, 117, 114, 110, 115, 32, 40, 114, 91, 50, 93, 44, 32, 114, 91, 53, 93, 44, 32, 114, 91, 51, 93, 41, 0 ], "i8", ALLOC_NORMAL);
    __str218 = allocate([ 111, 112, 101, 114, 97, 116, 111, 114, 46, 105, 116, 101, 109, 103, 101, 116, 116, 101, 114, 0 ], "i8", ALLOC_NORMAL);
    _itemgetter_type = allocate([ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 147947, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ], [ "i32", 0, 0, 0, "%struct._typeobject*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "void (%struct.PyObject*)*", 0, 0, 0, "i32 (%struct.PyObject*, %struct.FILE*, i32)*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, i8*)*", 0, 0, 0, "i32 (%struct.PyObject*, i8*, %struct.PyObject*)*", 0, 0, 0, "i32 (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*)*", 0, 0, 0, "%struct.PyNumberMethods*", 0, 0, 0, "%struct.PySequenceMethods*", 0, 0, 0, "%struct.PyMappingMethods*", 0, 0, 0, "i32 (%struct.PyObject*)*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*)*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32 (%struct.PyObject*, %struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "%struct.PyBufferProcs*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i32 (%struct.PyObject*, i32 (%struct.PyObject*, i8*)*, i8*)*", 0, 0, 0, "i32 (%struct.PyObject*)*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*, i32)*", 0, 0, 0, "i32", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*)*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*)*", 0, 0, 0, "%struct.PyMethodDef*", 0, 0, 0, "%struct.PyMemberDef*", 0, 0, 0, "%struct.PyGetSetDef*", 0, 0, 0, "%struct._typeobject*", 0, 0, 0, "%struct.PyObject*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32 (%struct.PyObject*, %struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i32 (%struct.PyObject*, %struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "%struct.PyObject* (%struct._typeobject*, i32)*", 0, 0, 0, "%struct.PyObject* (%struct._typeobject*, %struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "void (i8*)*", 0, 0, 0, "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8" ], ALLOC_NORMAL);
    __str219 = allocate([ 97, 116, 116, 114, 103, 101, 116, 116, 101, 114, 40, 41, 0 ], "i8", ALLOC_NORMAL);
    __str220 = allocate([ 97, 116, 116, 114, 103, 101, 116, 116, 101, 114, 0 ], "i8", ALLOC_NORMAL);
    __str221 = allocate([ 97, 116, 116, 114, 105, 98, 117, 116, 101, 32, 110, 97, 109, 101, 32, 109, 117, 115, 116, 32, 98, 101, 32, 97, 32, 115, 116, 114, 105, 110, 103, 0 ], "i8", ALLOC_NORMAL);
    __str222 = allocate([ 40, 40, 40, 40, 40, 40, 80, 121, 79, 98, 106, 101, 99, 116, 42, 41, 40, 97, 103, 45, 62, 97, 116, 116, 114, 41, 41, 45, 62, 111, 98, 95, 116, 121, 112, 101, 41, 41, 45, 62, 116, 112, 95, 102, 108, 97, 103, 115, 32, 38, 32, 40, 40, 49, 76, 60, 60, 50, 54, 41, 41, 41, 32, 33, 61, 32, 48, 41, 0 ], "i8", ALLOC_NORMAL);
    ___PRETTY_FUNCTION___9429 = allocate([ 97, 116, 116, 114, 103, 101, 116, 116, 101, 114, 95, 99, 97, 108, 108, 0 ], "i8", ALLOC_NORMAL);
    __str223 = allocate([ 40, 40, 40, 80, 121, 86, 97, 114, 79, 98, 106, 101, 99, 116, 42, 41, 40, 97, 103, 45, 62, 97, 116, 116, 114, 41, 41, 45, 62, 111, 98, 95, 115, 105, 122, 101, 41, 32, 61, 61, 32, 110, 97, 116, 116, 114, 115, 0 ], "i8", ALLOC_NORMAL);
    _attrgetter_doc = allocate([ 97, 116, 116, 114, 103, 101, 116, 116, 101, 114, 40, 97, 116, 116, 114, 44, 32, 46, 46, 46, 41, 32, 45, 45, 62, 32, 97, 116, 116, 114, 103, 101, 116, 116, 101, 114, 32, 111, 98, 106, 101, 99, 116, 10, 10, 82, 101, 116, 117, 114, 110, 32, 97, 32, 99, 97, 108, 108, 97, 98, 108, 101, 32, 111, 98, 106, 101, 99, 116, 32, 116, 104, 97, 116, 32, 102, 101, 116, 99, 104, 101, 115, 32, 116, 104, 101, 32, 103, 105, 118, 101, 110, 32, 97, 116, 116, 114, 105, 98, 117, 116, 101, 40, 115, 41, 32, 102, 114, 111, 109, 32, 105, 116, 115, 32, 111, 112, 101, 114, 97, 110, 100, 46, 10, 65, 102, 116, 101, 114, 44, 32, 102, 61, 97, 116, 116, 114, 103, 101, 116, 116, 101, 114, 40, 39, 110, 97, 109, 101, 39, 41, 44, 32, 116, 104, 101, 32, 99, 97, 108, 108, 32, 102, 40, 114, 41, 32, 114, 101, 116, 117, 114, 110, 115, 32, 114, 46, 110, 97, 109, 101, 46, 10, 65, 102, 116, 101, 114, 44, 32, 103, 61, 97, 116, 116, 114, 103, 101, 116, 116, 101, 114, 40, 39, 110, 97, 109, 101, 39, 44, 32, 39, 100, 97, 116, 101, 39, 41, 44, 32, 116, 104, 101, 32, 99, 97, 108, 108, 32, 103, 40, 114, 41, 32, 114, 101, 116, 117, 114, 110, 115, 32, 40, 114, 46, 110, 97, 109, 101, 44, 32, 114, 46, 100, 97, 116, 101, 41, 46, 10, 65, 102, 116, 101, 114, 44, 32, 104, 61, 97, 116, 116, 114, 103, 101, 116, 116, 101, 114, 40, 39, 110, 97, 109, 101, 46, 102, 105, 114, 115, 116, 39, 44, 32, 39, 110, 97, 109, 101, 46, 108, 97, 115, 116, 39, 41, 44, 32, 116, 104, 101, 32, 99, 97, 108, 108, 32, 104, 40, 114, 41, 32, 114, 101, 116, 117, 114, 110, 115, 10, 40, 114, 46, 110, 97, 109, 101, 46, 102, 105, 114, 115, 116, 44, 32, 114, 46, 110, 97, 109, 101, 46, 108, 97, 115, 116, 41, 46, 0 ], "i8", ALLOC_NORMAL);
    __str224 = allocate([ 111, 112, 101, 114, 97, 116, 111, 114, 46, 97, 116, 116, 114, 103, 101, 116, 116, 101, 114, 0 ], "i8", ALLOC_NORMAL);
    _attrgetter_type = allocate([ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 147947, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ], [ "i32", 0, 0, 0, "%struct._typeobject*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "void (%struct.PyObject*)*", 0, 0, 0, "i32 (%struct.PyObject*, %struct.FILE*, i32)*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, i8*)*", 0, 0, 0, "i32 (%struct.PyObject*, i8*, %struct.PyObject*)*", 0, 0, 0, "i32 (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*)*", 0, 0, 0, "%struct.PyNumberMethods*", 0, 0, 0, "%struct.PySequenceMethods*", 0, 0, 0, "%struct.PyMappingMethods*", 0, 0, 0, "i32 (%struct.PyObject*)*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*)*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32 (%struct.PyObject*, %struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "%struct.PyBufferProcs*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i32 (%struct.PyObject*, i32 (%struct.PyObject*, i8*)*, i8*)*", 0, 0, 0, "i32 (%struct.PyObject*)*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*, i32)*", 0, 0, 0, "i32", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*)*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*)*", 0, 0, 0, "%struct.PyMethodDef*", 0, 0, 0, "%struct.PyMemberDef*", 0, 0, 0, "%struct.PyGetSetDef*", 0, 0, 0, "%struct._typeobject*", 0, 0, 0, "%struct.PyObject*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32 (%struct.PyObject*, %struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i32 (%struct.PyObject*, %struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "%struct.PyObject* (%struct._typeobject*, i32)*", 0, 0, 0, "%struct.PyObject* (%struct._typeobject*, %struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "void (i8*)*", 0, 0, 0, "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8" ], ALLOC_NORMAL);
    __str225 = allocate([ 109, 101, 116, 104, 111, 100, 99, 97, 108, 108, 101, 114, 32, 110, 101, 101, 100, 115, 32, 97, 116, 32, 108, 101, 97, 115, 116, 32, 111, 110, 101, 32, 97, 114, 103, 117, 109, 101, 110, 116, 44, 32, 116, 104, 101, 32, 109, 101, 116, 104, 111, 100, 32, 110, 97, 109, 101, 0 ], "i8", ALLOC_NORMAL);
    __str226 = allocate([ 109, 101, 116, 104, 111, 100, 99, 97, 108, 108, 101, 114, 0 ], "i8", ALLOC_NORMAL);
    _methodcaller_doc = allocate([ 109, 101, 116, 104, 111, 100, 99, 97, 108, 108, 101, 114, 40, 110, 97, 109, 101, 44, 32, 46, 46, 46, 41, 32, 45, 45, 62, 32, 109, 101, 116, 104, 111, 100, 99, 97, 108, 108, 101, 114, 32, 111, 98, 106, 101, 99, 116, 10, 10, 82, 101, 116, 117, 114, 110, 32, 97, 32, 99, 97, 108, 108, 97, 98, 108, 101, 32, 111, 98, 106, 101, 99, 116, 32, 116, 104, 97, 116, 32, 99, 97, 108, 108, 115, 32, 116, 104, 101, 32, 103, 105, 118, 101, 110, 32, 109, 101, 116, 104, 111, 100, 32, 111, 110, 32, 105, 116, 115, 32, 111, 112, 101, 114, 97, 110, 100, 46, 10, 65, 102, 116, 101, 114, 44, 32, 102, 32, 61, 32, 109, 101, 116, 104, 111, 100, 99, 97, 108, 108, 101, 114, 40, 39, 110, 97, 109, 101, 39, 41, 44, 32, 116, 104, 101, 32, 99, 97, 108, 108, 32, 102, 40, 114, 41, 32, 114, 101, 116, 117, 114, 110, 115, 32, 114, 46, 110, 97, 109, 101, 40, 41, 46, 10, 65, 102, 116, 101, 114, 44, 32, 103, 32, 61, 32, 109, 101, 116, 104, 111, 100, 99, 97, 108, 108, 101, 114, 40, 39, 110, 97, 109, 101, 39, 44, 32, 39, 100, 97, 116, 101, 39, 44, 32, 102, 111, 111, 61, 49, 41, 44, 32, 116, 104, 101, 32, 99, 97, 108, 108, 32, 103, 40, 114, 41, 32, 114, 101, 116, 117, 114, 110, 115, 10, 114, 46, 110, 97, 109, 101, 40, 39, 100, 97, 116, 101, 39, 44, 32, 102, 111, 111, 61, 49, 41, 46, 0 ], "i8", ALLOC_NORMAL);
    __str227 = allocate([ 111, 112, 101, 114, 97, 116, 111, 114, 46, 109, 101, 116, 104, 111, 100, 99, 97, 108, 108, 101, 114, 0 ], "i8", ALLOC_NORMAL);
    _methodcaller_type = allocate([ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 147947, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ], [ "i32", 0, 0, 0, "%struct._typeobject*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "void (%struct.PyObject*)*", 0, 0, 0, "i32 (%struct.PyObject*, %struct.FILE*, i32)*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, i8*)*", 0, 0, 0, "i32 (%struct.PyObject*, i8*, %struct.PyObject*)*", 0, 0, 0, "i32 (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*)*", 0, 0, 0, "%struct.PyNumberMethods*", 0, 0, 0, "%struct.PySequenceMethods*", 0, 0, 0, "%struct.PyMappingMethods*", 0, 0, 0, "i32 (%struct.PyObject*)*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*)*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32 (%struct.PyObject*, %struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "%struct.PyBufferProcs*", 0, 0, 0, "i32", 0, 0, 0, "i8*", 0, 0, 0, "i32 (%struct.PyObject*, i32 (%struct.PyObject*, i8*)*, i8*)*", 0, 0, 0, "i32 (%struct.PyObject*)*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*, i32)*", 0, 0, 0, "i32", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*)*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*)*", 0, 0, 0, "%struct.PyMethodDef*", 0, 0, 0, "%struct.PyMemberDef*", 0, 0, 0, "%struct.PyGetSetDef*", 0, 0, 0, "%struct._typeobject*", 0, 0, 0, "%struct.PyObject*", 0, 0, 0, "%struct.PyObject* (%struct.PyObject*, %struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32 (%struct.PyObject*, %struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "i32", 0, 0, 0, "i32 (%struct.PyObject*, %struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "%struct.PyObject* (%struct._typeobject*, i32)*", 0, 0, 0, "%struct.PyObject* (%struct._typeobject*, %struct.PyObject*, %struct.PyObject*)*", 0, 0, 0, "void (i8*)*", 0, 0, 0, "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8", "i8" ], ALLOC_NORMAL);
    __str228 = allocate([ 111, 112, 101, 114, 97, 116, 111, 114, 0 ], "i8", ALLOC_NORMAL);
    HEAP[_operator_methods] = __str50;
    HEAP[_operator_methods + 4] = FUNCTION_TABLE_OFFSET + 2;
    HEAP[_operator_methods + 12] = __str51;
    HEAP[_operator_methods + 16] = __str52;
    HEAP[_operator_methods + 20] = FUNCTION_TABLE_OFFSET + 4;
    HEAP[_operator_methods + 28] = __str53;
    HEAP[_operator_methods + 32] = __str54;
    HEAP[_operator_methods + 36] = FUNCTION_TABLE_OFFSET + 6;
    HEAP[_operator_methods + 44] = __str55;
    HEAP[_operator_methods + 48] = __str56;
    HEAP[_operator_methods + 52] = FUNCTION_TABLE_OFFSET + 8;
    HEAP[_operator_methods + 60] = __str57;
    HEAP[_operator_methods + 64] = __str58;
    HEAP[_operator_methods + 68] = FUNCTION_TABLE_OFFSET + 10;
    HEAP[_operator_methods + 76] = __str59;
    HEAP[_operator_methods + 80] = __str60;
    HEAP[_operator_methods + 84] = FUNCTION_TABLE_OFFSET + 10;
    HEAP[_operator_methods + 92] = __str59;
    HEAP[_operator_methods + 96] = __str31;
    HEAP[_operator_methods + 100] = FUNCTION_TABLE_OFFSET + 12;
    HEAP[_operator_methods + 108] = __str61;
    HEAP[_operator_methods + 112] = __str32;
    HEAP[_operator_methods + 116] = FUNCTION_TABLE_OFFSET + 14;
    HEAP[_operator_methods + 124] = __str62;
    HEAP[_operator_methods + 128] = __str33;
    HEAP[_operator_methods + 132] = FUNCTION_TABLE_OFFSET + 16;
    HEAP[_operator_methods + 140] = __str63;
    HEAP[_operator_methods + 144] = __str64;
    HEAP[_operator_methods + 148] = FUNCTION_TABLE_OFFSET + 18;
    HEAP[_operator_methods + 156] = __str65;
    HEAP[_operator_methods + 160] = __str45;
    HEAP[_operator_methods + 164] = FUNCTION_TABLE_OFFSET + 20;
    HEAP[_operator_methods + 172] = __str66;
    HEAP[_operator_methods + 176] = __str46;
    HEAP[_operator_methods + 180] = FUNCTION_TABLE_OFFSET + 22;
    HEAP[_operator_methods + 188] = __str67;
    HEAP[_operator_methods + 192] = __str68;
    HEAP[_operator_methods + 196] = FUNCTION_TABLE_OFFSET + 24;
    HEAP[_operator_methods + 204] = __str69;
    HEAP[_operator_methods + 208] = __str70;
    HEAP[_operator_methods + 212] = FUNCTION_TABLE_OFFSET + 24;
    HEAP[_operator_methods + 220] = __str69;
    HEAP[_operator_methods + 224] = __str71;
    HEAP[_operator_methods + 228] = FUNCTION_TABLE_OFFSET + 26;
    HEAP[_operator_methods + 236] = __str72;
    HEAP[_operator_methods + 240] = __str73;
    HEAP[_operator_methods + 244] = FUNCTION_TABLE_OFFSET + 26;
    HEAP[_operator_methods + 252] = __str72;
    HEAP[_operator_methods + 256] = __str74;
    HEAP[_operator_methods + 260] = FUNCTION_TABLE_OFFSET + 28;
    HEAP[_operator_methods + 268] = __str75;
    HEAP[_operator_methods + 272] = __str76;
    HEAP[_operator_methods + 276] = FUNCTION_TABLE_OFFSET + 28;
    HEAP[_operator_methods + 284] = __str75;
    HEAP[_operator_methods + 288] = __str77;
    HEAP[_operator_methods + 292] = FUNCTION_TABLE_OFFSET + 30;
    HEAP[_operator_methods + 300] = __str78;
    HEAP[_operator_methods + 304] = __str79;
    HEAP[_operator_methods + 308] = FUNCTION_TABLE_OFFSET + 30;
    HEAP[_operator_methods + 316] = __str78;
    HEAP[_operator_methods + 320] = __str80;
    HEAP[_operator_methods + 324] = FUNCTION_TABLE_OFFSET + 32;
    HEAP[_operator_methods + 332] = __str81;
    HEAP[_operator_methods + 336] = __str82;
    HEAP[_operator_methods + 340] = FUNCTION_TABLE_OFFSET + 32;
    HEAP[_operator_methods + 348] = __str81;
    HEAP[_operator_methods + 352] = __str83;
    HEAP[_operator_methods + 356] = FUNCTION_TABLE_OFFSET + 34;
    HEAP[_operator_methods + 364] = __str84;
    HEAP[_operator_methods + 368] = __str85;
    HEAP[_operator_methods + 372] = FUNCTION_TABLE_OFFSET + 34;
    HEAP[_operator_methods + 380] = __str84;
    HEAP[_operator_methods + 384] = __str86;
    HEAP[_operator_methods + 388] = FUNCTION_TABLE_OFFSET + 36;
    HEAP[_operator_methods + 396] = __str87;
    HEAP[_operator_methods + 400] = __str88;
    HEAP[_operator_methods + 404] = FUNCTION_TABLE_OFFSET + 36;
    HEAP[_operator_methods + 412] = __str87;
    HEAP[_operator_methods + 416] = __str89;
    HEAP[_operator_methods + 420] = FUNCTION_TABLE_OFFSET + 38;
    HEAP[_operator_methods + 428] = __str90;
    HEAP[_operator_methods + 432] = __str91;
    HEAP[_operator_methods + 436] = FUNCTION_TABLE_OFFSET + 38;
    HEAP[_operator_methods + 444] = __str90;
    HEAP[_operator_methods + 448] = __str92;
    HEAP[_operator_methods + 452] = FUNCTION_TABLE_OFFSET + 40;
    HEAP[_operator_methods + 460] = __str93;
    HEAP[_operator_methods + 464] = __str94;
    HEAP[_operator_methods + 468] = FUNCTION_TABLE_OFFSET + 40;
    HEAP[_operator_methods + 476] = __str93;
    HEAP[_operator_methods + 480] = __str95;
    HEAP[_operator_methods + 484] = FUNCTION_TABLE_OFFSET + 42;
    HEAP[_operator_methods + 492] = __str96;
    HEAP[_operator_methods + 496] = __str97;
    HEAP[_operator_methods + 500] = FUNCTION_TABLE_OFFSET + 42;
    HEAP[_operator_methods + 508] = __str96;
    HEAP[_operator_methods + 512] = __str98;
    HEAP[_operator_methods + 516] = FUNCTION_TABLE_OFFSET + 44;
    HEAP[_operator_methods + 524] = __str99;
    HEAP[_operator_methods + 528] = __str100;
    HEAP[_operator_methods + 532] = FUNCTION_TABLE_OFFSET + 44;
    HEAP[_operator_methods + 540] = __str99;
    HEAP[_operator_methods + 544] = __str101;
    HEAP[_operator_methods + 548] = FUNCTION_TABLE_OFFSET + 46;
    HEAP[_operator_methods + 556] = __str102;
    HEAP[_operator_methods + 560] = __str103;
    HEAP[_operator_methods + 564] = FUNCTION_TABLE_OFFSET + 46;
    HEAP[_operator_methods + 572] = __str102;
    HEAP[_operator_methods + 576] = __str104;
    HEAP[_operator_methods + 580] = FUNCTION_TABLE_OFFSET + 48;
    HEAP[_operator_methods + 588] = __str105;
    HEAP[_operator_methods + 592] = __str106;
    HEAP[_operator_methods + 596] = FUNCTION_TABLE_OFFSET + 48;
    HEAP[_operator_methods + 604] = __str105;
    HEAP[_operator_methods + 608] = __str107;
    HEAP[_operator_methods + 612] = FUNCTION_TABLE_OFFSET + 50;
    HEAP[_operator_methods + 620] = __str108;
    HEAP[_operator_methods + 624] = __str109;
    HEAP[_operator_methods + 628] = FUNCTION_TABLE_OFFSET + 50;
    HEAP[_operator_methods + 636] = __str108;
    HEAP[_operator_methods + 640] = __str110;
    HEAP[_operator_methods + 644] = FUNCTION_TABLE_OFFSET + 52;
    HEAP[_operator_methods + 652] = __str111;
    HEAP[_operator_methods + 656] = __str112;
    HEAP[_operator_methods + 660] = FUNCTION_TABLE_OFFSET + 52;
    HEAP[_operator_methods + 668] = __str111;
    HEAP[_operator_methods + 672] = __str113;
    HEAP[_operator_methods + 676] = FUNCTION_TABLE_OFFSET + 54;
    HEAP[_operator_methods + 684] = __str114;
    HEAP[_operator_methods + 688] = __str115;
    HEAP[_operator_methods + 692] = FUNCTION_TABLE_OFFSET + 54;
    HEAP[_operator_methods + 700] = __str114;
    HEAP[_operator_methods + 704] = __str116;
    HEAP[_operator_methods + 708] = FUNCTION_TABLE_OFFSET + 56;
    HEAP[_operator_methods + 716] = __str117;
    HEAP[_operator_methods + 720] = __str118;
    HEAP[_operator_methods + 724] = FUNCTION_TABLE_OFFSET + 56;
    HEAP[_operator_methods + 732] = __str117;
    HEAP[_operator_methods + 736] = __str119;
    HEAP[_operator_methods + 740] = FUNCTION_TABLE_OFFSET + 58;
    HEAP[_operator_methods + 748] = __str120;
    HEAP[_operator_methods + 752] = __str121;
    HEAP[_operator_methods + 756] = FUNCTION_TABLE_OFFSET + 58;
    HEAP[_operator_methods + 764] = __str120;
    HEAP[_operator_methods + 768] = __str122;
    HEAP[_operator_methods + 772] = FUNCTION_TABLE_OFFSET + 60;
    HEAP[_operator_methods + 780] = __str123;
    HEAP[_operator_methods + 784] = __str124;
    HEAP[_operator_methods + 788] = FUNCTION_TABLE_OFFSET + 60;
    HEAP[_operator_methods + 796] = __str123;
    HEAP[_operator_methods + 800] = __str125;
    HEAP[_operator_methods + 804] = FUNCTION_TABLE_OFFSET + 62;
    HEAP[_operator_methods + 812] = __str126;
    HEAP[_operator_methods + 816] = __str127;
    HEAP[_operator_methods + 820] = FUNCTION_TABLE_OFFSET + 62;
    HEAP[_operator_methods + 828] = __str126;
    HEAP[_operator_methods + 832] = __str128;
    HEAP[_operator_methods + 836] = FUNCTION_TABLE_OFFSET + 64;
    HEAP[_operator_methods + 844] = __str129;
    HEAP[_operator_methods + 848] = __str130;
    HEAP[_operator_methods + 852] = FUNCTION_TABLE_OFFSET + 64;
    HEAP[_operator_methods + 860] = __str129;
    HEAP[_operator_methods + 864] = __str131;
    HEAP[_operator_methods + 868] = FUNCTION_TABLE_OFFSET + 66;
    HEAP[_operator_methods + 876] = __str132;
    HEAP[_operator_methods + 880] = __str133;
    HEAP[_operator_methods + 884] = FUNCTION_TABLE_OFFSET + 66;
    HEAP[_operator_methods + 892] = __str132;
    HEAP[_operator_methods + 896] = __str134;
    HEAP[_operator_methods + 900] = FUNCTION_TABLE_OFFSET + 68;
    HEAP[_operator_methods + 908] = __str135;
    HEAP[_operator_methods + 912] = __str136;
    HEAP[_operator_methods + 916] = FUNCTION_TABLE_OFFSET + 68;
    HEAP[_operator_methods + 924] = __str135;
    HEAP[_operator_methods + 928] = __str137;
    HEAP[_operator_methods + 932] = FUNCTION_TABLE_OFFSET + 70;
    HEAP[_operator_methods + 940] = __str138;
    HEAP[_operator_methods + 944] = __str139;
    HEAP[_operator_methods + 948] = FUNCTION_TABLE_OFFSET + 70;
    HEAP[_operator_methods + 956] = __str138;
    HEAP[_operator_methods + 960] = __str140;
    HEAP[_operator_methods + 964] = FUNCTION_TABLE_OFFSET + 72;
    HEAP[_operator_methods + 972] = __str141;
    HEAP[_operator_methods + 976] = __str142;
    HEAP[_operator_methods + 980] = FUNCTION_TABLE_OFFSET + 72;
    HEAP[_operator_methods + 988] = __str141;
    HEAP[_operator_methods + 992] = __str143;
    HEAP[_operator_methods + 996] = FUNCTION_TABLE_OFFSET + 74;
    HEAP[_operator_methods + 1004] = __str144;
    HEAP[_operator_methods + 1008] = __str145;
    HEAP[_operator_methods + 1012] = FUNCTION_TABLE_OFFSET + 74;
    HEAP[_operator_methods + 1020] = __str144;
    HEAP[_operator_methods + 1024] = __str146;
    HEAP[_operator_methods + 1028] = FUNCTION_TABLE_OFFSET + 76;
    HEAP[_operator_methods + 1036] = __str147;
    HEAP[_operator_methods + 1040] = __str148;
    HEAP[_operator_methods + 1044] = FUNCTION_TABLE_OFFSET + 76;
    HEAP[_operator_methods + 1052] = __str147;
    HEAP[_operator_methods + 1056] = __str149;
    HEAP[_operator_methods + 1060] = FUNCTION_TABLE_OFFSET + 78;
    HEAP[_operator_methods + 1068] = __str150;
    HEAP[_operator_methods + 1072] = __str151;
    HEAP[_operator_methods + 1076] = FUNCTION_TABLE_OFFSET + 78;
    HEAP[_operator_methods + 1084] = __str150;
    HEAP[_operator_methods + 1088] = __str152;
    HEAP[_operator_methods + 1092] = FUNCTION_TABLE_OFFSET + 80;
    HEAP[_operator_methods + 1100] = __str153;
    HEAP[_operator_methods + 1104] = __str154;
    HEAP[_operator_methods + 1108] = FUNCTION_TABLE_OFFSET + 80;
    HEAP[_operator_methods + 1116] = __str153;
    HEAP[_operator_methods + 1120] = __str155;
    HEAP[_operator_methods + 1124] = FUNCTION_TABLE_OFFSET + 82;
    HEAP[_operator_methods + 1132] = __str156;
    HEAP[_operator_methods + 1136] = __str157;
    HEAP[_operator_methods + 1140] = FUNCTION_TABLE_OFFSET + 82;
    HEAP[_operator_methods + 1148] = __str156;
    HEAP[_operator_methods + 1152] = __str158;
    HEAP[_operator_methods + 1156] = FUNCTION_TABLE_OFFSET + 84;
    HEAP[_operator_methods + 1164] = __str159;
    HEAP[_operator_methods + 1168] = __str160;
    HEAP[_operator_methods + 1172] = FUNCTION_TABLE_OFFSET + 84;
    HEAP[_operator_methods + 1180] = __str159;
    HEAP[_operator_methods + 1184] = __str161;
    HEAP[_operator_methods + 1188] = FUNCTION_TABLE_OFFSET + 86;
    HEAP[_operator_methods + 1196] = __str162;
    HEAP[_operator_methods + 1200] = __str163;
    HEAP[_operator_methods + 1204] = FUNCTION_TABLE_OFFSET + 86;
    HEAP[_operator_methods + 1212] = __str162;
    HEAP[_operator_methods + 1216] = __str164;
    HEAP[_operator_methods + 1220] = FUNCTION_TABLE_OFFSET + 88;
    HEAP[_operator_methods + 1228] = __str165;
    HEAP[_operator_methods + 1232] = __str166;
    HEAP[_operator_methods + 1236] = FUNCTION_TABLE_OFFSET + 88;
    HEAP[_operator_methods + 1244] = __str165;
    HEAP[_operator_methods + 1248] = __str167;
    HEAP[_operator_methods + 1252] = FUNCTION_TABLE_OFFSET + 90;
    HEAP[_operator_methods + 1260] = __str168;
    HEAP[_operator_methods + 1264] = __str169;
    HEAP[_operator_methods + 1268] = FUNCTION_TABLE_OFFSET + 90;
    HEAP[_operator_methods + 1276] = __str168;
    HEAP[_operator_methods + 1280] = __str170;
    HEAP[_operator_methods + 1284] = FUNCTION_TABLE_OFFSET + 92;
    HEAP[_operator_methods + 1292] = __str171;
    HEAP[_operator_methods + 1296] = __str172;
    HEAP[_operator_methods + 1300] = FUNCTION_TABLE_OFFSET + 92;
    HEAP[_operator_methods + 1308] = __str171;
    HEAP[_operator_methods + 1312] = __str173;
    HEAP[_operator_methods + 1316] = FUNCTION_TABLE_OFFSET + 94;
    HEAP[_operator_methods + 1324] = __str174;
    HEAP[_operator_methods + 1328] = __str175;
    HEAP[_operator_methods + 1332] = FUNCTION_TABLE_OFFSET + 94;
    HEAP[_operator_methods + 1340] = __str174;
    HEAP[_operator_methods + 1344] = __str176;
    HEAP[_operator_methods + 1348] = FUNCTION_TABLE_OFFSET + 96;
    HEAP[_operator_methods + 1356] = __str177;
    HEAP[_operator_methods + 1360] = __str178;
    HEAP[_operator_methods + 1364] = FUNCTION_TABLE_OFFSET + 96;
    HEAP[_operator_methods + 1372] = __str177;
    HEAP[_operator_methods + 1376] = __str179;
    HEAP[_operator_methods + 1380] = FUNCTION_TABLE_OFFSET + 98;
    HEAP[_operator_methods + 1388] = __str180;
    HEAP[_operator_methods + 1392] = __str181;
    HEAP[_operator_methods + 1396] = FUNCTION_TABLE_OFFSET + 98;
    HEAP[_operator_methods + 1404] = __str180;
    HEAP[_operator_methods + 1408] = __str43;
    HEAP[_operator_methods + 1412] = FUNCTION_TABLE_OFFSET + 100;
    HEAP[_operator_methods + 1420] = __str182;
    HEAP[_operator_methods + 1424] = __str183;
    HEAP[_operator_methods + 1428] = FUNCTION_TABLE_OFFSET + 100;
    HEAP[_operator_methods + 1436] = __str182;
    HEAP[_operator_methods + 1440] = __str44;
    HEAP[_operator_methods + 1444] = FUNCTION_TABLE_OFFSET + 102;
    HEAP[_operator_methods + 1452] = __str184;
    HEAP[_operator_methods + 1456] = __str185;
    HEAP[_operator_methods + 1460] = FUNCTION_TABLE_OFFSET + 102;
    HEAP[_operator_methods + 1468] = __str184;
    HEAP[_operator_methods + 1472] = __str186;
    HEAP[_operator_methods + 1476] = FUNCTION_TABLE_OFFSET + 104;
    HEAP[_operator_methods + 1484] = __str187;
    HEAP[_operator_methods + 1488] = __str188;
    HEAP[_operator_methods + 1492] = FUNCTION_TABLE_OFFSET + 104;
    HEAP[_operator_methods + 1500] = __str187;
    HEAP[_operator_methods + 1504] = __str189;
    HEAP[_operator_methods + 1508] = FUNCTION_TABLE_OFFSET + 106;
    HEAP[_operator_methods + 1516] = __str190;
    HEAP[_operator_methods + 1520] = __str191;
    HEAP[_operator_methods + 1524] = FUNCTION_TABLE_OFFSET + 106;
    HEAP[_operator_methods + 1532] = __str190;
    HEAP[_operator_methods + 1536] = __str192;
    HEAP[_operator_methods + 1540] = FUNCTION_TABLE_OFFSET + 108;
    HEAP[_operator_methods + 1548] = __str193;
    HEAP[_operator_methods + 1552] = __str194;
    HEAP[_operator_methods + 1556] = FUNCTION_TABLE_OFFSET + 108;
    HEAP[_operator_methods + 1564] = __str193;
    HEAP[_operator_methods + 1568] = __str195;
    HEAP[_operator_methods + 1572] = FUNCTION_TABLE_OFFSET + 110;
    HEAP[_operator_methods + 1580] = __str196;
    HEAP[_operator_methods + 1584] = __str197;
    HEAP[_operator_methods + 1588] = FUNCTION_TABLE_OFFSET + 110;
    HEAP[_operator_methods + 1596] = __str196;
    HEAP[_operator_methods + 1600] = __str198;
    HEAP[_operator_methods + 1604] = FUNCTION_TABLE_OFFSET + 112;
    HEAP[_operator_methods + 1612] = __str199;
    HEAP[_operator_methods + 1616] = __str200;
    HEAP[_operator_methods + 1620] = FUNCTION_TABLE_OFFSET + 112;
    HEAP[_operator_methods + 1628] = __str199;
    HEAP[_operator_methods + 1632] = __str201;
    HEAP[_operator_methods + 1636] = FUNCTION_TABLE_OFFSET + 114;
    HEAP[_operator_methods + 1644] = __str202;
    HEAP[_operator_methods + 1648] = __str203;
    HEAP[_operator_methods + 1652] = FUNCTION_TABLE_OFFSET + 114;
    HEAP[_operator_methods + 1660] = __str202;
    HEAP[_operator_methods + 1664] = __str204;
    HEAP[_operator_methods + 1668] = FUNCTION_TABLE_OFFSET + 116;
    HEAP[_operator_methods + 1676] = __str205;
    HEAP[_operator_methods + 1680] = __str206;
    HEAP[_operator_methods + 1684] = FUNCTION_TABLE_OFFSET + 116;
    HEAP[_operator_methods + 1692] = __str205;
    HEAP[_operator_methods + 1696] = __str207;
    HEAP[_operator_methods + 1700] = FUNCTION_TABLE_OFFSET + 118;
    HEAP[_operator_methods + 1708] = __str208;
    HEAP[_operator_methods + 1712] = __str209;
    HEAP[_operator_methods + 1716] = FUNCTION_TABLE_OFFSET + 118;
    HEAP[_operator_methods + 1724] = __str208;
    HEAP[_operator_methods + 1728] = __str210;
    HEAP[_operator_methods + 1732] = FUNCTION_TABLE_OFFSET + 120;
    HEAP[_operator_methods + 1740] = __str211;
    HEAP[_operator_methods + 1744] = __str212;
    HEAP[_operator_methods + 1748] = FUNCTION_TABLE_OFFSET + 120;
    HEAP[_operator_methods + 1756] = __str211;
    HEAP[_itemgetter_type + 12] = __str218;
    HEAP[_itemgetter_type + 24] = FUNCTION_TABLE_OFFSET + 122;
    HEAP[_itemgetter_type + 64] = FUNCTION_TABLE_OFFSET + 124;
    HEAP[_itemgetter_type + 72] = FUNCTION_TABLE_OFFSET + 126;
    HEAP[_itemgetter_type + 88] = _itemgetter_doc;
    HEAP[_itemgetter_type + 92] = FUNCTION_TABLE_OFFSET + 128;
    HEAP[_itemgetter_type + 156] = FUNCTION_TABLE_OFFSET + 130;
    HEAP[_attrgetter_type + 12] = __str224;
    HEAP[_attrgetter_type + 24] = FUNCTION_TABLE_OFFSET + 132;
    HEAP[_attrgetter_type + 64] = FUNCTION_TABLE_OFFSET + 134;
    HEAP[_attrgetter_type + 72] = FUNCTION_TABLE_OFFSET + 126;
    HEAP[_attrgetter_type + 88] = _attrgetter_doc;
    HEAP[_attrgetter_type + 92] = FUNCTION_TABLE_OFFSET + 136;
    HEAP[_attrgetter_type + 156] = FUNCTION_TABLE_OFFSET + 138;
    HEAP[_methodcaller_type + 12] = __str227;
    HEAP[_methodcaller_type + 24] = FUNCTION_TABLE_OFFSET + 140;
    HEAP[_methodcaller_type + 64] = FUNCTION_TABLE_OFFSET + 142;
    HEAP[_methodcaller_type + 72] = FUNCTION_TABLE_OFFSET + 126;
    HEAP[_methodcaller_type + 88] = _methodcaller_doc;
    HEAP[_methodcaller_type + 92] = FUNCTION_TABLE_OFFSET + 144;
    HEAP[_methodcaller_type + 156] = FUNCTION_TABLE_OFFSET + 146;
    __globalConstructor__();
  }
  Module["run"] = run;
  run();
  return Module;
});
